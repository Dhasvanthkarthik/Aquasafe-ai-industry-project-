# AquaSafe AI – Platform Startup Tool
Clear-Host
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " AquaSafe AI – Intelligent Environmental Intelligence" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host ""

# Check Docker
$docker = Get-Command docker -ErrorAction SilentlyContinue

if ($docker) {
    Write-Host "[INFO] Docker detected. Initiating containerized services..." -ForegroundColor Green
    Write-Host "[CMD] docker compose up --build" -ForegroundColor Gray
    docker compose up --build
} else {
    Write-Host "[WARNING] Docker compose is not running or not installed." -ForegroundColor Yellow
    Write-Host "Please start Docker Desktop, or run the following to boot locally:" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Backend local setup:" -ForegroundColor White
    Write-Host "  cd backend" -ForegroundColor Gray
    Write-Host "  python -m venv venv" -ForegroundColor Gray
    Write-Host "  .\\venv\\Scripts\\Activate.ps1" -ForegroundColor Gray
    Write-Host "  pip install -r requirements.txt" -ForegroundColor Gray
    Write-Host "  python -m app.seed" -ForegroundColor Gray
    Write-Host "  uvicorn app.main:app --reload" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Frontend local setup:" -ForegroundColor White
    Write-Host "  cd frontend" -ForegroundColor Gray
    Write-Host "  npm install" -ForegroundColor Gray
    Write-Host "  npm run dev" -ForegroundColor Gray
}
