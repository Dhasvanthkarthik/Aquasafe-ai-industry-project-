import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { PrivateRoute } from './components/PrivateRoute';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';

// Pages
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Dashboard } from './pages/Dashboard';
import { GISMap } from './pages/GISMap';
import { Predictor } from './pages/Predictor';
import { DatasetManager } from './pages/DatasetManager';
import { ModelStudio } from './pages/ModelStudio';
import { Chatbot } from './pages/Chatbot';
import { AlertCenter } from './pages/AlertCenter';
import { Forecast } from './pages/Forecast';
import { LakeComparison } from './pages/LakeComparison';
import { DigitalTwin } from './pages/DigitalTwin';
import { AdminPanel } from './pages/AdminPanel';

// Shared Layout Wrapper
const AppLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { theme } = useTheme();

  return (
    <div className={`min-h-screen flex ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
      
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarOpen ? 'pl-64' : 'pl-20'}`}>
        <Navbar />
        <main className="flex-1 overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <Routes>
            {/* Public Auth pages */}
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* Protected Core Platform */}
            <Route element={<PrivateRoute />}>
              <Route element={<AppLayout />}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/map" element={<GISMap />} />
                <Route path="/predictions" element={<Predictor />} />
                <Route path="/forecast" element={<Forecast />} />
                <Route path="/compare" element={<LakeComparison />} />
                <Route path="/twin" element={<DigitalTwin />} />
                <Route path="/chatbot" element={<Chatbot />} />
                <Route path="/alerts" element={<AlertCenter />} />
                
                {/* Researcher specific portals */}
                <Route element={<PrivateRoute allowedRoles={['admin', 'researcher']} />}>
                  <Route path="/datasets" element={<DatasetManager />} />
                  <Route path="/models" element={<ModelStudio />} />
                </Route>
                
                {/* Admin specific console */}
                <Route element={<PrivateRoute allowedRoles={['admin']} />}>
                  <Route path="/admin" element={<AdminPanel />} />
                </Route>
              </Route>
            </Route>

            {/* Fallback to dashboard */}
            <Route path="*" element={<Login />} />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
