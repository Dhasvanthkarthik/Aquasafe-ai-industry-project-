import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { 
  Bell, AlertTriangle, ShieldCheck, Check, Trash2, Calendar, Compass 
} from 'lucide-react';
import api from '../services/api';

export const AlertCenter: React.FC = () => {
  const { theme } = useTheme();
  const { isResearcher } = useAuth();
  
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    try {
      const res = await api.get('/alerts/');
      setAlerts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  const handleResolve = async (id: number) => {
    try {
      await api.put(`/alerts/${id}/resolve`);
      setAlerts(prev => prev.map(a => a.id === id ? { ...a, is_resolved: true } : a));
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="h-[calc(100vh-4rem)] w-full flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-2"></div>
        <span className="text-sm ml-2">Loading Alert Center...</span>
      </div>
    );
  }

  const activeAlerts = alerts.filter(a => !a.is_resolved);
  const resolvedAlerts = alerts.filter(a => a.is_resolved);

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Active Warnings Column */}
        <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5 text-red-400">
            <AlertTriangle className="w-5 h-5" /> Active Warnings ({activeAlerts.length})
          </h4>
          
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            {activeAlerts.length === 0 ? (
              <div className="text-center py-16 text-slate-500 flex flex-col items-center justify-center gap-2">
                <ShieldCheck className="w-12 h-12 text-teal-500 animate-pulse-slow" />
                <p className="font-bold text-sm text-slate-400">No active warnings</p>
                <p className="text-xs max-w-xs">All monitored stations reporting chemical parameters within standard levels.</p>
              </div>
            ) : (
              activeAlerts.map(alert => (
                <div key={alert.id} className="p-4 bg-red-500/5 border border-red-500/25 rounded-2xl flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-red-500/10 text-red-500 px-2 py-0.5 rounded text-[10px] font-extrabold uppercase">Critical</span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(alert.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm font-semibold leading-relaxed text-slate-200">{alert.message}</p>
                  </div>
                  {isResearcher && (
                    <button 
                      onClick={() => handleResolve(alert.id)}
                      className="p-1.5 rounded-lg bg-teal-600/10 text-teal-400 border border-teal-500/20 hover:bg-teal-600 hover:text-white transition-all cursor-pointer shrink-0"
                      title="Resolve Threat"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Audit Log / Resolved warnings */}
        <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5 text-slate-400">
            <ShieldCheck className="w-5 h-5 text-teal-400" /> Resolved Warnings ({resolvedAlerts.length})
          </h4>

          <div className="space-y-3.5 max-h-[60vh] overflow-y-auto pr-1">
            {resolvedAlerts.length === 0 ? (
              <div className="text-center py-16 text-slate-500 text-xs">
                No archived warnings registered.
              </div>
            ) : (
              resolvedAlerts.map(alert => (
                <div key={alert.id} className="p-3.5 bg-slate-950/30 border border-slate-850 rounded-2xl flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-[9px] font-bold">Resolved</span>
                      <span className="text-[9px] text-slate-500">{new Date(alert.created_at).toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-slate-400 leading-snug">{alert.message}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
