import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { 
  MessageSquare, Send, Sparkles, AlertCircle, RefreshCw, Info 
} from 'lucide-react';
import api from '../services/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  sources?: string[];
}

export const Chatbot: React.FC = () => {
  const { theme } = useTheme();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Hello! I am the AquaSafe AI Research Assistant. I can help explain water quality indicators, explain our machine learning models, suggest remediation strategies, or explain specific predictions. What would you like to explore today?",
      sources: ["System Initialization"]
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim() || sending) return;
    
    // Add user message
    const userMsg: Message = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setSending(true);

    try {
      const res = await api.post('/chatbot/', {
        message: text,
        history: messages.map(m => ({ role: m.role, content: m.content }))
      });
      
      const assistantMsg: Message = {
        role: 'assistant',
        content: res.data.response,
        sources: res.data.sources
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I apologize, but I encountered an error connecting to the AI inference services. Please verify your local Ollama status or API credentials."
      }]);
    } finally {
      setSending(false);
    }
  };

  const suggestions = [
    "What causes cyanobacterial blooms?",
    "Suggest preventive measures.",
    "Explain SHAP values.",
    "Explain Random Forest.",
    "What is the N:P ratio?"
  ];

  return (
    <div className={`p-6 h-[calc(100vh-4rem)] flex flex-col justify-between transition-all
      ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}
    >
      {/* Suggestions and top banner */}
      <div className="mb-4">
        <div className={`p-4 rounded-2xl flex items-start gap-3 border ${
          theme === 'dark' ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <Info className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold text-sm">AquaSafe AI Chat Assistant</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              This assistant checks environment variables for Gemini or OpenAI keys. If none are present, it queries local Ollama models (Llama 3), and falls back seamlessly to a local Water Ecology Knowledge Base.
            </p>
          </div>
        </div>
      </div>

      {/* Message Feed Area */}
      <div className={`flex-1 overflow-y-auto p-4 rounded-2xl border mb-4 space-y-4 max-h-[55vh]
        ${theme === 'dark' ? 'bg-slate-950 border-slate-800/80' : 'bg-white border-slate-200 shadow-inner'}`}
      >
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[75%] rounded-2xl p-4 text-sm leading-relaxed ${
              m.role === 'user'
                ? 'bg-teal-600 text-white rounded-br-none shadow-md'
                : (theme === 'dark' ? 'bg-slate-900 border border-slate-850 rounded-bl-none' : 'bg-slate-100 text-slate-800 rounded-bl-none')
            }`}>
              <p className="whitespace-pre-line">{m.content}</p>
              
              {m.sources && m.sources.length > 0 && (
                <span className="block text-[9px] text-slate-400/90 font-mono mt-2 tracking-wider">
                  SOURCE: {m.sources.join(', ')}
                </span>
              )}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className={`rounded-2xl p-4 text-xs font-semibold flex items-center gap-2 ${
              theme === 'dark' ? 'bg-slate-900 border border-slate-850' : 'bg-slate-100 text-slate-600'
            }`}>
              <RefreshCw className="w-4 h-4 animate-spin text-teal-400" /> Synthesizing environmental context...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Chips */}
      {messages.length === 1 && (
        <div className="mb-4 flex flex-wrap gap-2 justify-center">
          {suggestions.map((s, i) => (
            <button
              key={i}
              onClick={() => handleSend(s)}
              className="text-xs font-medium px-3.5 py-2 rounded-full border border-slate-800 hover:border-teal-500/50 hover:bg-teal-600/5 hover:text-teal-400 transition-all cursor-pointer bg-slate-900/40"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input box */}
      <form 
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(inputValue);
        }}
        className="flex gap-3"
      >
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Ask about bloom causes, water quality index parameters, or SHAP graphs..."
          className="flex-1 bg-slate-900/40 border border-slate-800 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-teal-500 transition-all"
        />
        <button
          type="submit"
          disabled={!inputValue.trim() || sending}
          className="px-5 py-3 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition-all flex items-center justify-center shrink-0 cursor-pointer disabled:opacity-50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
};
