import React, { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { 
  Activity, Cpu, CheckCircle2, ShieldCheck, Thermometer, Droplet, 
  Wind, Zap, Play, Square 
} from 'lucide-react';
import { motion } from 'framer-motion';

export const DigitalTwin: React.FC = () => {
  const { theme } = useTheme();
  const [sensors, setSensors] = useState<any[]>([
    { id: 1, name: 'S-Node Alpha', parameter: 'pH', value: 8.2, status: 'Active', signal: 'Good' },
    { id: 2, name: 'S-Node Beta', parameter: 'DO (mg/L)', value: 4.1, status: 'Active', signal: 'Good' },
    { id: 3, name: 'S-Node Gamma', parameter: 'Water Temp (°C)', value: 29.2, status: 'Active', signal: 'Excellent' },
    { id: 4, name: 'S-Node Delta', parameter: 'Turbidity (NTU)', value: 18.5, status: 'Maintenance', signal: 'Weak' }
  ]);
  const [simulationActive, setSimulationActive] = useState(true);

  // Simulate real-time IoT adjustments
  useEffect(() => {
    let interval: any;
    if (simulationActive) {
      interval = setInterval(() => {
        setSensors(prev => prev.map(s => {
          if (s.status === 'Active') {
            const diff = (Math.random() - 0.5) * 0.15;
            return {
              ...s,
              value: parseFloat((s.value + diff).toFixed(2))
            };
          }
          return s;
        }));
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [simulationActive]);

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Virtual Model Canvas */}
        <div className={`lg:col-span-8 p-6 rounded-3xl shadow-xl flex flex-col justify-between min-h-[450px] relative overflow-hidden ${
          theme === 'dark' ? 'glass-card' : 'glass-card-light'
        }`}>
          {/* Animated Water Background representation */}
          <div className="absolute inset-0 bg-gradient-to-br from-teal-950/20 via-sky-950/10 to-slate-950/40 pointer-events-none"></div>
          
          <div className="flex items-center justify-between relative z-10">
            <div>
              <span className="text-[10px] text-teal-400 font-bold uppercase tracking-wider block">Real-time Digital Simulation</span>
              <h3 className="text-xl font-black mt-0.5">Lake Telemetry Twin</h3>
            </div>
            
            <button 
              onClick={() => setSimulationActive(!simulationActive)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                simulationActive 
                  ? 'bg-red-500/10 text-red-500 border-red-500/20 hover:bg-red-50' 
                  : 'bg-teal-500/10 text-teal-400 border-teal-500/20 hover:bg-teal-600 hover:text-white'
              }`}
            >
              {simulationActive ? <><Square className="w-3 h-3" /> Pause IoT stream</> : <><Play className="w-3 h-3" /> Resume IoT stream</>}
            </button>
          </div>

          {/* Virtual Lake Visual representation with floating nodes */}
          <div className="flex-1 my-6 relative rounded-2xl bg-slate-950/70 border border-slate-900 flex items-center justify-center min-h-[250px]">
            <div className="absolute w-72 h-36 bg-teal-500/5 rounded-full filter blur-xl animate-pulse-slow"></div>
            
            {/* Visual float nodes */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 relative z-10 w-full px-8">
              {sensors.map((s, idx) => (
                <motion.div 
                  key={s.id}
                  animate={simulationActive ? { y: [0, -6, 0] } : {}}
                  transition={{ duration: 3 + idx, repeat: Infinity, ease: "easeInOut" }}
                  className={`p-4 rounded-2xl text-center border relative bg-slate-900 shadow-xl ${
                    s.status === 'Active' ? 'border-teal-500/20' : 'border-yellow-500/20'
                  }`}
                >
                  {/* Pulse Indicator */}
                  <div className="absolute top-2 right-2 flex h-2 w-2">
                    <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                      s.status === 'Active' ? 'bg-teal-400' : 'bg-yellow-400'
                    }`}></span>
                    <span className={`relative inline-flex rounded-full h-2 w-2 ${
                      s.status === 'Active' ? 'bg-teal-500' : 'bg-yellow-500'
                    }`}></span>
                  </div>

                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">{s.name}</span>
                  <span className="text-2xl font-black text-white mt-1 block">{s.value}</span>
                  <span className="text-[10px] text-teal-400 font-semibold block mt-0.5">{s.parameter}</span>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="relative z-10 flex items-center justify-between text-xs text-slate-400 border-t border-slate-900 pt-3">
            <span>Gateway Protocol: MQTT / WebSocket active</span>
            <span className="text-teal-400 font-semibold">Latency: 45ms</span>
          </div>
        </div>

        {/* Sensor diagnostics list */}
        <div className="lg:col-span-4 space-y-6">
          <div className={`p-6 rounded-3xl shadow-xl flex flex-col justify-between h-full ${
            theme === 'dark' ? 'glass-card' : 'glass-card-light'
          }`}>
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Cpu className="w-5 h-5 text-sky-400" /> IoT Gateway Status</h4>
              
              <div className="space-y-4">
                {sensors.map((s) => (
                  <div key={s.id} className="p-3 bg-slate-950/30 border border-slate-800/80 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-slate-200">{s.name}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">Signal strength: {s.signal}</p>
                    </div>
                    <div className="text-right">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        s.status === 'Active' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                      }`}>{s.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 border-t border-slate-800/10 pt-4">
              <span className="text-xs text-slate-400 leading-relaxed block bg-slate-950/30 p-3 rounded-xl">
                <b>Digital Twin Sync:</b> Automatically reflects real-time biological sensor inputs. Use MQTT client libraries to push data to `mqtt://iot.aquasafe.ai/lakes/{1}/telemetry` in production.
              </span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
