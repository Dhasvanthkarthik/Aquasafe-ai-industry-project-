import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useTheme } from '../context/ThemeContext';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  Compass, Thermometer, CloudRain, Info, ShieldAlert, CheckCircle, 
  MapPin, CloudSun, Eye, Calendar, Sparkles
} from 'lucide-react';
import L from 'leaflet';
import api from '../services/api';

// Create custom colored HTML markers to prevent Leaflet asset resolution bugs
const createCustomMarker = (risk: string) => {
  const color = risk === 'High' ? '#DC2626' : (risk === 'Moderate' ? '#CA8A04' : '#16A34A');
  const html = `
    <div style="position: relative; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
      <div style="position: absolute; width: 100%; height: 100%; border-radius: 50%; background-color: ${color}; opacity: 0.25; animation: ping 1.8s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="width: 14px; height: 14px; border-radius: 50%; background-color: ${color}; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>
    </div>
  `;
  return L.divIcon({
    html,
    className: 'custom-leaflet-marker',
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
};

export const GISMap: React.FC = () => {
  const { theme } = useTheme();
  const [lakes, setLakes] = useState<any[]>([]);
  const [selectedLake, setSelectedLake] = useState<any>(null);
  const [lakeHistory, setLakeHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLakesAndPredictions = async () => {
      try {
        const [lakesRes, predsRes] = await Promise.all([
          api.get('/lakes'),
          api.get('/predictions/history')
        ]);
        
        const preds = predsRes.data;
        const mappedLakes = lakesRes.data.map((lake: any) => {
          // Find latest prediction for this lake
          const lakePreds = preds.filter((p: any) => p.lake_id === lake.id);
          const latestPred = lakePreds.length > 0 ? lakePreds[0] : null;
          
          return {
            ...lake,
            latestPrediction: latestPred,
            history: lakePreds.reverse() // Chronological for graph
          };
        });
        
        setLakes(mappedLakes);
        if (mappedLakes.length > 0) {
          setSelectedLake(mappedLakes[0]);
          setLakeHistory(mappedLakes[0].history || []);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLakesAndPredictions();
  }, []);

  const handleSelectLake = (lake: any) => {
    setSelectedLake(lake);
    setLakeHistory(lake.history || []);
  };

  if (loading) {
    return (
      <div className="h-[calc(100vh-4rem)] w-full flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-2"></div>
        <span className="text-sm ml-2">Loading GIS spatial mapping...</span>
      </div>
    );
  }

  // Current weather mockup for selected location
  const currentRisk = selectedLake?.latestPrediction?.health_risk || 'Low';
  const riskColor = currentRisk === 'High' ? 'text-red-500' : (currentRisk === 'Moderate' ? 'text-yellow-500' : 'text-green-500');

  return (
    <div className={`h-[calc(100vh-4rem)] w-full flex flex-col md:flex-row overflow-hidden transition-all
      ${theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}
    >
      
      {/* Map Area */}
      <div className="flex-1 h-2/3 md:h-full relative p-4">
        <MapContainer 
          center={[40.0, -98.0]} 
          zoom={4} 
          style={{ height: '100%', width: '100%', borderRadius: '16px' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
            url={theme === 'dark' 
              ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' 
              : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'}
          />
          {lakes.map((lake) => (
            <Marker 
              key={lake.id} 
              position={[lake.latitude, lake.longitude]}
              icon={createCustomMarker(lake.latestPrediction?.health_risk || 'Low')}
              eventHandlers={{
                click: () => handleSelectLake(lake),
              }}
            >
              <Popup>
                <div className="text-slate-900 p-1 font-sans">
                  <h4 className="font-bold text-sm mb-0.5">{lake.name}</h4>
                  <p className="text-xs mb-1">Code: {lake.location_code}</p>
                  <span className={`text-xs font-bold ${
                    lake.latestPrediction?.health_risk === 'High' ? 'text-red-600' : (lake.latestPrediction?.health_risk === 'Moderate' ? 'text-yellow-600' : 'text-green-600')
                  }`}>
                    Risk: {lake.latestPrediction?.health_risk || 'Low'}
                  </span>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Side Panel Drawer */}
      <div className={`w-full md:w-96 h-1/3 md:h-full overflow-y-auto border-t md:border-t-0 md:border-l p-6 flex flex-col justify-between transition-all
        ${theme === 'dark' ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-2xl'}`}
      >
        {selectedLake ? (
          <div className="space-y-5">
            {/* Header */}
            <div>
              <span className="text-xs text-teal-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" /> Environmental Station
              </span>
              <h3 className="text-xl font-black mt-1 leading-snug">{selectedLake.name}</h3>
              <p className="text-xs text-slate-400">Lat: {selectedLake.latitude.toFixed(4)}, Long: {selectedLake.longitude.toFixed(4)}</p>
            </div>

            {/* Risk Badge card */}
            <div className={`p-4 rounded-2xl flex items-center gap-3.5 border ${
              theme === 'dark' ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className={`w-3.5 h-3.5 rounded-full bg-current ${riskColor}`}></div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Health Risk Status</span>
                <span className={`text-base font-bold ${riskColor}`}>{currentRisk} Risk</span>
              </div>
            </div>

            {/* Current Metrics grid */}
            {selectedLake.latestPrediction && (
              <div className="grid grid-cols-2 gap-3.5">
                <div className={`p-3 rounded-xl border ${theme === 'dark' ? 'bg-slate-950/30 border-slate-800/60' : 'bg-slate-50/50 border-slate-100'}`}>
                  <span className="text-[10px] text-slate-400 block">Temperature</span>
                  <span className="text-sm font-semibold flex items-center gap-1 mt-0.5"><Thermometer className="w-3.5 h-3.5 text-teal-400" /> {selectedLake.latestPrediction.temperature} °C</span>
                </div>
                <div className={`p-3 rounded-xl border ${theme === 'dark' ? 'bg-slate-950/30 border-slate-800/60' : 'bg-slate-50/50 border-slate-100'}`}>
                  <span className="text-[10px] text-slate-400 block">pH Level</span>
                  <span className="text-sm font-semibold flex items-center gap-1 mt-0.5"><Sparkles className="w-3.5 h-3.5 text-sky-400" /> {selectedLake.latestPrediction.ph}</span>
                </div>
                <div className={`p-3 rounded-xl border ${theme === 'dark' ? 'bg-slate-950/30 border-slate-800/60' : 'bg-slate-50/50 border-slate-100'}`}>
                  <span className="text-[10px] text-slate-400 block">Phosphorus</span>
                  <span className="text-sm font-semibold mt-0.5">{selectedLake.latestPrediction.phosphorus} mg/L</span>
                </div>
                <div className={`p-3 rounded-xl border ${theme === 'dark' ? 'bg-slate-950/30 border-slate-800/60' : 'bg-slate-50/50 border-slate-100'}`}>
                  <span className="text-[10px] text-slate-400 block">DO Level</span>
                  <span className="text-sm font-semibold mt-0.5">{selectedLake.latestPrediction.dissolved_oxygen} mg/L</span>
                </div>
              </div>
            )}

            {/* Satellite Intelligence Overlay Mock */}
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-sky-400" /> Sentinel Satellite Imagery
              </h4>
              <div className="relative rounded-2xl overflow-hidden h-28 border border-slate-800/50 bg-slate-950/80 flex items-center justify-center">
                {/* Simulated satellite greenness index layer */}
                <div className="absolute inset-0 bg-gradient-to-tr from-green-950/40 via-teal-950/20 to-sky-950/30 opacity-70"></div>
                <span className="text-xs text-teal-400 font-semibold relative z-10 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Sentinel-2 RGB NDVI active
                </span>
              </div>
            </div>

            {/* Historical Charts */}
            {lakeHistory.length > 0 && (
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-teal-400" /> Historical Trend (pH)
                </h4>
                <div className="h-28">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={lakeHistory}>
                      <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #1e293b' }} />
                      <Line type="monotone" dataKey="ph" stroke="#0ea5e9" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
            
            {/* Recommendations */}
            {selectedLake.latestPrediction?.recommendations && (
              <div className="pt-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-emerald-400" /> Action Directives
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed bg-slate-950/20 dark:bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                  {selectedLake.latestPrediction.recommendations}
                </p>
              </div>
            )}

          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-center text-slate-400 text-xs">
            Select a lake marker on the map to review telemetry.
          </div>
        )}
      </div>

    </div>
  );
};
