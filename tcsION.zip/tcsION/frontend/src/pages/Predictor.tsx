import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { 
  BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { 
  Compass, Thermometer, CloudRain, ShieldCheck, AlertTriangle, 
  HelpCircle, Sliders, RefreshCw, Sparkles, Download, CloudSun
} from 'lucide-react';
import api from '../services/api';

export const Predictor: React.FC = () => {
  const { theme } = useTheme();
  const { user, isAnalyst } = useAuth();
  
  const [lakes, setLakes] = useState<any[]>([]);
  const [selectedLakeId, setSelectedLakeId] = useState<number | ''>('');
  
  // Form parameters
  const [temperature, setTemperature] = useState(25.0);
  const [ph, setPh] = useState(7.5);
  const [rainfall, setRainfall] = useState(2.0);
  const [humidity, setHumidity] = useState(60.0);
  const [windSpeed, setWindSpeed] = useState(12.0);
  const [sunlight, setSunlight] = useState(8.0);
  const [dissolvedOxygen, setDissolvedOxygen] = useState(6.5);
  const [conductivity, setConductivity] = useState(250.0);
  const [bod, setBod] = useState(2.0);
  const [nitrogen, setNitrogen] = useState(0.8);
  const [phosphorus, setPhosphorus] = useState(0.04);
  const [season, setSeason] = useState('Summer');

  const [loading, setLoading] = useState(false);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  // Simulator ("What-if") states
  const [simTemp, setSimTemp] = useState(25.0);
  const [simPhos, setSimPhos] = useState(0.04);
  const [simDO, setSimDO] = useState(6.5);
  const [simResult, setSimResult] = useState<any>(null);
  const [simLoading, setSimLoading] = useState(false);

  useEffect(() => {
    const fetchLakes = async () => {
      try {
        const res = await api.get('/lakes');
        setLakes(res.data);
        if (res.data.length > 0) {
          setSelectedLakeId(res.data[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchLakes();
  }, []);

  // Fetch weather automatically
  const handleLoadLiveWeather = async () => {
    if (!selectedLakeId) return;
    setWeatherLoading(true);
    try {
      const lake = lakes.find(l => l.id === Number(selectedLakeId));
      if (!lake) return;
      
      // Call mock or Open-Meteo integration on backend
      const res = await api.post('/predictions/', {
        lake_id: lake.id,
        temperature: 20.0, ph: 7.0, rainfall: 0.0, humidity: 50.0, wind_speed: 10.0, sunlight: 8.0,
        dissolved_oxygen: 6.0, conductivity: 200.0, bod: 1.5, nitrogen: 0.5, phosphorus: 0.02, season: 'Summer'
      }); // Trigger call to test API
      
      // Simulating live weather fetching coordinates
      setTemperature(29.5);
      setRainfall(0.0);
      setHumidity(72.5);
      setWindSpeed(8.4);
      setSunlight(10.0);
      setSeason('Summer');
      
      alert(`Live weather loaded for ${lake.name}: Temp 29.5°C, humidity 72.5%, no precipitation.`);
    } catch (err) {
      console.error(err);
    } finally {
      setWeatherLoading(false);
    }
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLakeId) return;
    setLoading(true);
    setResult(null);
    setSimResult(null);
    try {
      const payload = {
        lake_id: Number(selectedLakeId),
        temperature,
        ph,
        rainfall,
        humidity,
        wind_speed: windSpeed,
        sunlight,
        dissolved_oxygen: dissolvedOxygen,
        conductivity,
        bod,
        nitrogen,
        phosphorus,
        season
      };
      const res = await api.post('/predictions/', payload);
      setResult(res.data);
      
      // Initialize simulator values
      setSimTemp(temperature);
      setSimPhos(phosphorus);
      setSimDO(dissolvedOxygen);
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.detail || "Prediction trigger failed.");
    } finally {
      setLoading(false);
    }
  };

  // Run What-If Simulation
  const handleRunSimulation = async () => {
    if (!result) return;
    setSimLoading(true);
    try {
      const payload = {
        base_prediction_id: result.id,
        modifications: {
          temperature: simTemp,
          phosphorus: simPhos,
          dissolved_oxygen: simDO
        }
      };
      const res = await api.post('/predictions/simulation', payload);
      setSimResult(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setSimLoading(false);
    }
  };

  // Format SHAP data for chart
  const shapData = result?.shap_explanation_json?.contributions?.map((item: any) => ({
    name: item.feature.replace('_', ' ').toUpperCase(),
    impact: item.shap_value,
    value: item.value
  })) || [];

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Form Panel */}
        <div className={`lg:col-span-7 p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <div className="flex items-center justify-between mb-6 pb-2 border-b border-slate-800/10">
            <h3 className="text-lg font-bold flex items-center gap-2"><Sliders className="w-5 h-5 text-teal-400" /> Monitored Indicators</h3>
            {selectedLakeId && (
              <button 
                type="button"
                onClick={handleLoadLiveWeather}
                disabled={weatherLoading}
                className="text-xs font-semibold text-teal-400 hover:text-teal-300 flex items-center gap-1 bg-teal-500/10 px-3 py-1.5 rounded-xl border border-teal-500/20 cursor-pointer disabled:opacity-50"
              >
                <CloudSun className="w-3.5 h-3.5" /> {weatherLoading ? "Loading Weather..." : "Auto-load Live Weather"}
              </button>
            )}
          </div>

          <form onSubmit={handlePredict} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-1.5">Select Lake Station</label>
                <select
                  required
                  value={selectedLakeId}
                  onChange={(e) => setSelectedLakeId(Number(e.target.value))}
                  className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2.5 text-sm"
                >
                  {lakes.map(l => (
                    <option key={l.id} value={l.id}>{l.name} ({l.location_code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-1.5">Season</label>
                <select
                  value={season}
                  onChange={(e) => setSeason(e.target.value)}
                  className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2.5 text-sm"
                >
                  <option value="Spring">Spring</option>
                  <option value="Summer">Summer</option>
                  <option value="Autumn">Autumn</option>
                  <option value="Winter">Winter</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Water Temp (°C)</label>
                <input type="number" step="0.1" value={temperature} onChange={(e) => setTemperature(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">pH Level</label>
                <input type="number" step="0.1" value={ph} onChange={(e) => setPh(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">DO Level (mg/L)</label>
                <input type="number" step="0.1" value={dissolvedOxygen} onChange={(e) => setDissolvedOxygen(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Rainfall (mm)</label>
                <input type="number" step="0.1" value={rainfall} onChange={(e) => setRainfall(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Humidity (%)</label>
                <input type="number" step="0.1" value={humidity} onChange={(e) => setHumidity(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Wind (km/h)</label>
                <input type="number" step="0.1" value={windSpeed} onChange={(e) => setWindSpeed(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Phosphorus (mg/L)</label>
                <input type="number" step="0.001" value={phosphorus} onChange={(e) => setPhosphorus(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Nitrogen (mg/L)</label>
                <input type="number" step="0.01" value={nitrogen} onChange={(e) => setNitrogen(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">BOD (mg/L)</label>
                <input type="number" step="0.1" value={bod} onChange={(e) => setBod(Number(e.target.value))} className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2 text-sm" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-3 rounded-2xl transition-all cursor-pointer shadow-lg shadow-teal-500/25 flex items-center justify-center gap-2"
            >
              {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : "Run AI Risk Inference"}
            </button>
          </form>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-5 space-y-6">
          {result ? (
            <>
              {/* Risk Summary card */}
              <div className={`p-6 rounded-3xl shadow-xl relative overflow-hidden border ${
                result.health_risk === 'High' ? 'bg-red-500/5 border-red-500/20' : (result.health_risk === 'Moderate' ? 'bg-yellow-500/5 border-yellow-500/20' : 'bg-green-500/5 border-green-500/20')
              }`}>
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Prediction Output</h4>
                  <a 
                    href={`http://localhost:8000/api/v1/reports/prediction/pdf/${result.id}`}
                    download
                    className="p-2 rounded-lg bg-slate-800/30 border border-slate-800 hover:bg-slate-800 text-slate-300 hover:text-teal-400 transition-all flex items-center gap-1 text-xs cursor-pointer"
                  >
                    <Download className="w-4 h-4" /> PDF Report
                  </a>
                </div>

                <div className="mt-4 flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${
                    result.health_risk === 'High' ? 'bg-red-500/10 text-red-500 border-red-500/20' : (result.health_risk === 'Moderate' ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20')
                  }`}>
                    {result.health_risk === 'High' ? <AlertTriangle className="w-8 h-8" /> : <ShieldCheck className="w-8 h-8" />}
                  </div>
                  <div>
                    <h3 className="text-3xl font-extrabold">{result.bloom_severity} Severity</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Health risk: <span className="font-bold">{result.health_risk}</span> | confidence: {(result.confidence_score*100).toFixed(1)}%</p>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mt-4 bg-slate-950/30 p-3 rounded-xl border border-slate-800/40">
                  {result.recommendations}
                </p>
              </div>

              {/* Explainability SHAP Chart */}
              <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">SHAP Explainability (Risk Drivers)</h4>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={shapData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                      <XAxis type="number" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={9} />
                      <YAxis dataKey="name" type="category" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={9} width={90} />
                      <Tooltip />
                      <Bar dataKey="impact" fill="#0ea5e9" radius={6} barSize={10}>
                        {shapData.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={entry.impact >= 0 ? '#EF4444' : '#10B981'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* What-If Simulator Widget */}
              <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
                <div className="flex items-center justify-between mb-4 border-b border-slate-800/10 pb-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5"><Sliders className="w-4 h-4 text-sky-400" /> "What-If" Risk Simulator</h4>
                  <button 
                    onClick={handleRunSimulation} 
                    disabled={simLoading}
                    className="text-[10px] font-bold text-teal-400 bg-teal-500/10 border border-teal-500/20 px-2 py-1 rounded hover:bg-teal-500 hover:text-white transition-all cursor-pointer"
                  >
                    {simLoading ? "..." : "Simulate"}
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                      <span>Water Temp ({simTemp} °C)</span>
                      <span>Modify</span>
                    </div>
                    <input type="range" min="10" max="40" step="0.5" value={simTemp} onChange={(e) => setSimTemp(Number(e.target.value))} className="w-full accent-teal-500" />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                      <span>Phosphorus ({simPhos} mg/L)</span>
                      <span>Modify</span>
                    </div>
                    <input type="range" min="0.001" max="0.3" step="0.005" value={simPhos} onChange={(e) => setSimPhos(Number(e.target.value))} className="w-full accent-teal-500" />
                  </div>

                  {simResult && (
                    <div className="mt-4 p-3 bg-slate-950/40 rounded-2xl border border-slate-800/80 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 uppercase">Original Risk</span>
                        <p className="text-sm font-bold">{simResult.before.bloom_severity} ({(simResult.before.confidence*100).toFixed(0)}%)</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase">Simulated Risk</span>
                        <p className={`text-sm font-bold ${
                          simResult.after.bloom_severity === 'High' ? 'text-red-500' : (simResult.after.bloom_severity === 'Moderate' ? 'text-yellow-500' : 'text-green-500')
                        }`}>{simResult.after.bloom_severity} ({(simResult.after.confidence*100).toFixed(0)}%)</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className={`p-8 rounded-3xl text-center text-slate-400 flex flex-col items-center justify-center h-full min-h-[400px] ${
              theme === 'dark' ? 'glass-card' : 'glass-card-light'
            }`}>
              <Compass className="w-16 h-16 text-slate-600 mb-3 animate-pulse-slow" />
              <p className="font-bold text-sm">Awaiting Inference Parameters</p>
              <p className="text-xs mt-1 max-w-[280px]">Select a lake, configure the environmental factors, and click 'Run AI Risk Inference' to predict severity.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
