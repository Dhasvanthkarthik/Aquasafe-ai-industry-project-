import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { TrendingUp, Thermometer, CloudRain, Clock } from 'lucide-react';
import api from '../services/api';

export const Forecast: React.FC = () => {
  const { theme } = useTheme();
  
  const [lakes, setLakes] = useState<any[]>([]);
  const [selectedLakeId, setSelectedLakeId] = useState<number | ''>('');
  
  const [forecast, setForecast] = useState<any[]>([]);
  const [loadingForecast, setLoadingForecast] = useState(false);

  useEffect(() => {
    const fetchLakes = async () => {
      try {
        const res = await api.get('/lakes');
        setLakes(res.data);
        if (res.data.length > 0) {
          setSelectedLakeId(res.data[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchLakes();
  }, []);

  useEffect(() => {
    const fetchForecast = async () => {
      if (!selectedLakeId) return;
      setLoadingForecast(true);
      try {
        const res = await api.get(`/predictions/forecast/${selectedLakeId}`);
        setForecast(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingForecast(false);
      }
    };
    fetchForecast();
  }, [selectedLakeId]);

  // Format Recharts data (map day to shorter formats and assign probabilities)
  const chartData = forecast.map((f: any) => {
    const dateObj = new Date(f.day);
    const dayName = dateObj.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
    
    // Heuristic probability weights from predicted class
    const highProb = f.probabilities?.High || (f.bloom_severity === 'High' ? 0.85 : (f.bloom_severity === 'Moderate' ? 0.40 : 0.05));
    const modProb = f.probabilities?.Moderate || (f.bloom_severity === 'High' ? 0.10 : (f.bloom_severity === 'Moderate' ? 0.50 : 0.10));
    
    return {
      day: dayName,
      'High Risk Prob': parseFloat((highProb * 100).toFixed(0)),
      'Moderate Risk Prob': parseFloat((modProb * 100).toFixed(0)),
      Temp: f.temperature,
      Rain: f.rainfall
    };
  });

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      {/* Lake selector & options */}
      <div className={`p-5 rounded-2xl shadow-xl flex flex-col md:flex-row items-center gap-4 justify-between ${
        theme === 'dark' ? 'glass-card' : 'glass-card-light'
      }`}>
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold">Predictive Bloom Forecast</h3>
            <p className="text-xs text-slate-400 mt-0.5">Integrates meteorological forecast paths to calculate future bloom triggers.</p>
          </div>
        </div>

        <div className="w-full md:w-64">
          <select 
            value={selectedLakeId} 
            onChange={(e) => setSelectedLakeId(Number(e.target.value))} 
            className="w-full bg-slate-950/40 border border-slate-800/80 p-2.5 rounded-xl text-sm"
          >
            {lakes.map(l => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Forecast Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        <div className={`lg:col-span-8 p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-6 flex items-center gap-1.5"><Clock className="w-4 h-4 text-sky-400" /> 7-Day Bloom Probability Curves</h4>
          
          <div className="h-80">
            {loadingForecast ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">Loading forecast...</div>
            ) : chartData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-500">No forecast data.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="day" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={9} />
                  <YAxis unit="%" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={9} />
                  <Tooltip />
                  <Legend />
                  <defs>
                    <linearGradient id="colorHigh" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#EF4444" stopOpacity={0.0}/>
                    </linearGradient>
                    <linearGradient id="colorMod" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#EAB308" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="High Risk Prob" stroke="#EF4444" strokeWidth={2.5} fillOpacity={1} fill="url(#colorHigh)" />
                  <Area type="monotone" dataKey="Moderate Risk Prob" stroke="#EAB308" strokeWidth={2} fillOpacity={1} fill="url(#colorMod)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Daily Forecast List cards */}
        <div className="lg:col-span-4 space-y-4">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">Daily Weather & Risk Timeline</h4>
          
          <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
            {loadingForecast ? (
              <div className="text-center py-6 text-xs text-slate-400">Loading daily timeline...</div>
            ) : (
              forecast.map((f, idx) => (
                <div key={idx} className={`p-3 bg-slate-950/30 border border-slate-800 rounded-2xl flex items-center justify-between`}>
                  <div>
                    <p className="text-xs font-bold text-slate-200">
                      {new Date(f.day).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                    </p>
                    <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1">
                      <span className="flex items-center gap-0.5"><Thermometer className="w-3 h-3 text-teal-400" /> {f.temperature} °C</span>
                      <span className="flex items-center gap-0.5"><CloudRain className="w-3 h-3 text-sky-400" /> {f.rainfall} mm</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      f.bloom_severity === 'High' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : (f.bloom_severity === 'Moderate' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20')
                    }`}>{f.bloom_severity} Risk</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
