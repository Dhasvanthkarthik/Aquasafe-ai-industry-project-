import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { 
  Cpu, Play, CheckCircle2, AlertTriangle, Trash2, Shield, RefreshCw 
} from 'lucide-react';
import api from '../services/api';

export const ModelStudio: React.FC = () => {
  const { theme } = useTheme();
  const { isResearcher, isAdmin } = useAuth();
  
  const [datasets, setDatasets] = useState<any[]>([]);
  const [models, setModels] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | ''>('');
  
  const [training, setTraining] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [datasetsRes, modelsRes] = await Promise.all([
        api.get('/datasets/'),
        api.get('/models/')
      ]);
      setDatasets(datasetsRes.data);
      setModels(modelsRes.data);
      if (datasetsRes.data.length > 0) {
        setSelectedDatasetId(datasetsRes.data[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleTrain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDatasetId) return;
    setTraining(true);
    try {
      await api.post(`/models/train?dataset_id=${selectedDatasetId}`);
      await fetchData();
      alert("Models trained successfully! The top-performing model has been auto-activated.");
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.detail || "Training failed. Please verify the dataset columns.");
    } finally {
      setTraining(false);
    }
  };

  const handleActivateModel = async (id: number) => {
    try {
      await api.put(`/models/${id}/activate`);
      await fetchData();
      alert("Model activated for core prediction pipeline.");
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.detail || "Failed to activate model.");
    }
  };

  const handleDeleteModel = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this model entry?")) return;
    try {
      await api.delete(`/models/${id}`);
      setModels(prev => prev.filter(m => m.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="h-[calc(100vh-4rem)] w-full flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-2"></div>
        <span className="text-sm ml-2">Loading Model Studio registry...</span>
      </div>
    );
  }

  // Format Recharts comparison data for top 5 models
  const chartData = models.slice(0, 5).map(m => ({
    name: m.name.split(' ')[0], // RandomForest, CatBoost etc
    Accuracy: m.accuracy,
    F1: m.f1_score,
    Recall: m.recall_score
  }));

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Training Console */}
        {isResearcher && (
          <div className={`lg:col-span-4 p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
            <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Play className="w-4 h-4 text-teal-400" /> ML Studio Trainer</h4>
            
            <form onSubmit={handleTrain} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-1.5">Select Training Dataset</label>
                <select
                  required
                  value={selectedDatasetId}
                  onChange={(e) => setSelectedDatasetId(Number(e.target.value))}
                  className="w-full bg-slate-950/40 border border-slate-800/60 rounded-xl p-2.5 text-sm"
                >
                  {datasets.length === 0 ? (
                    <option value="">-- No datasets available --</option>
                  ) : (
                    datasets.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.row_count} rows)</option>
                    ))
                  )}
                </select>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 block leading-relaxed bg-slate-950/30 p-3 border border-slate-800/50 rounded-xl">
                  <b>Hyperparameter Settings:</b> AquaSafe AI uses auto-tuned Stratified 5-Fold cross validation on 7 classifiers: Random Forest, SVM, MLP, Gradient Boosting, XGBoost, CatBoost, and LightGBM.
                </span>
              </div>

              <button
                type="submit"
                disabled={training || !selectedDatasetId}
                className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-2.5 rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-teal-600/20"
              >
                {training ? <RefreshCw className="w-5 h-5 animate-spin" /> : "Initiate Model Training"}
              </button>
            </form>
          </div>
        )}

        {/* Model comparisons chart */}
        <div className={`lg:col-span-8 p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-4">Registry Comparison Summary</h4>
          <div className="h-60">
            {chartData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-500">Train models to generate performance metrics chart.</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="name" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={10} />
                  <YAxis domain={[0.5, 1.0]} stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={10} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Accuracy" fill="#0d9488" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="F1" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

      </div>

      {/* Model Registry List */}
      <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
        <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Cpu className="w-5 h-5 text-sky-400" /> Active Model Registry</h4>
        
        <div className="overflow-x-auto border border-slate-800 rounded-2xl">
          <table className="min-w-full divide-y divide-slate-800 text-xs text-left">
            <thead className="bg-slate-950/60 font-semibold text-slate-300">
              <tr>
                <th className="px-4 py-3 font-bold">Model Designation</th>
                <th className="px-4 py-3 font-bold">Type</th>
                <th className="px-4 py-3 font-bold">Accuracy</th>
                <th className="px-4 py-3 font-bold">Precision</th>
                <th className="px-4 py-3 font-bold">Recall</th>
                <th className="px-4 py-3 font-bold">F1-Score</th>
                <th className="px-4 py-3 font-bold">AUC-ROC</th>
                <th className="px-4 py-3 font-bold">Status</th>
                <th className="px-4 py-3 font-bold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 bg-slate-950/20">
              {models.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-500">No models registered yet. Go to Dataset Manager and upload a training set to begin.</td>
                </tr>
              ) : (
                models.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-800/10">
                    <td className="px-4 py-3 font-bold">{m.name}</td>
                    <td className="px-4 py-3">{m.model_type}</td>
                    <td className="px-4 py-3">{m.accuracy.toFixed(4)}</td>
                    <td className="px-4 py-3">{m.precision_score.toFixed(4)}</td>
                    <td className="px-4 py-3">{m.recall_score.toFixed(4)}</td>
                    <td className="px-4 py-3 font-bold text-teal-400">{m.f1_score.toFixed(4)}</td>
                    <td className="px-4 py-3">{m.auc_score.toFixed(4)}</td>
                    <td className="px-4 py-3">
                      {m.is_active ? (
                        <span className="bg-teal-500/10 text-teal-400 border border-teal-500/20 px-2 py-0.5 rounded-full font-bold">Active</span>
                      ) : (
                        <span className="text-slate-500">Inactive</span>
                      )}
                    </td>
                    <td className="px-4 py-3 flex items-center gap-2">
                      {!m.is_active && m.file_path && (
                        <button 
                          onClick={() => handleActivateModel(m.id)}
                          className="text-[10px] font-bold text-teal-400 bg-teal-500/10 hover:bg-teal-600 hover:text-white border border-teal-500/20 px-2.5 py-1 rounded transition-colors cursor-pointer"
                        >
                          Activate
                        </button>
                      )}
                      {isAdmin && (
                        <button 
                          onClick={() => handleDeleteModel(m.id)}
                          className="p-1 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                          title="Delete model entry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
