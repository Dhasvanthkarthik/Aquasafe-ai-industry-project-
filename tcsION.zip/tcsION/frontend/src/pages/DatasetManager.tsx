import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { 
  Database, Upload, Trash2, Eye, FileText, CheckCircle2, 
  AlertTriangle, RefreshCw, BarChart2, Check
} from 'lucide-react';
import api from '../services/api';

export const DatasetManager: React.FC = () => {
  const { theme } = useTheme();
  const { isResearcher } = useAuth();
  
  const [datasets, setDatasets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const [selectedDataset, setSelectedDataset] = useState<any>(null);
  const [previewData, setPreviewData] = useState<any>(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  const fetchDatasets = async () => {
    try {
      const res = await api.get('/datasets/');
      setDatasets(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatasets();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      await api.post('/datasets/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setSelectedFile(null);
      // Reset input element
      const fileInput = document.getElementById('file-upload-input') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
      
      await fetchDatasets();
      alert("Dataset uploaded and processed successfully!");
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.detail || "Upload failed. Verify column names and file contents.");
    } finally {
      setUploading(false);
    }
  };

  const handlePreviewDataset = async (dataset: any) => {
    setSelectedDataset(dataset);
    setPreviewLoading(true);
    setPreviewData(null);
    try {
      const res = await api.get(`/datasets/${dataset.id}/preview?rows=8`);
      setPreviewData(res.data);
    } catch (err) {
      console.error(err);
      alert("Failed to load dataset preview.");
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleDeleteDataset = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this dataset?")) return;
    try {
      await api.delete(`/datasets/${id}`);
      setDatasets(prev => prev.filter(d => d.id !== id));
      if (selectedDataset?.id === id) {
        setSelectedDataset(null);
        setPreviewData(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="h-[calc(100vh-4rem)] w-full flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-2"></div>
        <span className="text-sm ml-2">Loading datasets...</span>
      </div>
    );
  }

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Upload & List Panel */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* File Upload card */}
          {isResearcher && (
            <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
              <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Upload className="w-4 h-4 text-teal-400" /> Upload Lake Dataset</h4>
              
              <form onSubmit={handleUpload} className="space-y-4">
                <div className="border-2 border-dashed border-slate-800 rounded-2xl p-6 text-center hover:border-teal-500/50 transition-all relative">
                  <input 
                    type="file" 
                    id="file-upload-input"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <Database className="w-10 h-10 text-slate-500 mx-auto mb-2 animate-pulse-slow" />
                  <p className="text-xs font-semibold text-slate-300">
                    {selectedFile ? selectedFile.name : "Drag & drop CSV or Excel file"}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-1">Supports up to 25MB (.csv, .xlsx)</p>
                </div>
                
                <button
                  type="submit"
                  disabled={!selectedFile || uploading}
                  className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-2.5 rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {uploading ? <RefreshCw className="w-5 h-5 animate-spin" /> : "Upload & Analyze"}
                </button>
              </form>
            </div>
          )}

          {/* List of Datasets */}
          <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
            <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Database className="w-4 h-4 text-sky-400" /> Uploaded Datasets</h4>
            
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {datasets.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-xs">
                  No datasets uploaded yet.
                </div>
              ) : (
                datasets.map((d) => (
                  <div key={d.id} className="p-3 bg-slate-950/30 border border-slate-800 rounded-xl flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate flex items-center gap-1.5"><FileText className="w-4 h-4 text-teal-400 shrink-0" /> {d.name}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{d.row_count} rows | {d.col_count} columns</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button 
                        onClick={() => handlePreviewDataset(d)}
                        className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors cursor-pointer"
                        title="View profiling data"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDeleteDataset(d.id)}
                        className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                        title="Delete dataset"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

        {/* Profiling / Preview Panel */}
        <div className="lg:col-span-7">
          {selectedDataset ? (
            <div className={`p-6 rounded-3xl shadow-xl space-y-6 ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
              <div>
                <span className="text-[10px] text-teal-400 font-bold uppercase tracking-wider block">Data Profile & Quality Report</span>
                <h3 className="text-lg font-black mt-0.5 leading-snug">{selectedDataset.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Uploaded on {new Date(selectedDataset.upload_timestamp).toLocaleString()}</p>
              </div>

              {/* Statistics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3 bg-slate-950/30 border border-slate-800 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block">Quality Score</span>
                  <span className={`text-lg font-bold ${
                    selectedDataset.data_quality_score > 80 ? 'text-green-400' : 'text-yellow-400'
                  }`}>{selectedDataset.data_quality_score}%</span>
                </div>
                <div className="p-3 bg-slate-950/30 border border-slate-800 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block">Missing Values</span>
                  <span className="text-lg font-bold text-yellow-500">{selectedDataset.missing_count}</span>
                </div>
                <div className="p-3 bg-slate-950/30 border border-slate-800 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block">Duplicates</span>
                  <span className="text-lg font-bold text-orange-400">{selectedDataset.duplicate_count}</span>
                </div>
                <div className="p-3 bg-slate-950/30 border border-slate-800 rounded-2xl text-center">
                  <span className="text-[10px] text-slate-400 block">Outliers</span>
                  <span className="text-lg font-bold text-red-400">{selectedDataset.outlier_count}</span>
                </div>
              </div>

              {/* Preview Table */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Dataset Preview (First 8 Rows)</h4>
                {previewLoading ? (
                  <div className="h-40 flex items-center justify-center text-xs text-slate-400">Loading preview rows...</div>
                ) : previewData ? (
                  <div className="overflow-x-auto border border-slate-800 rounded-2xl">
                    <table className="min-w-full divide-y divide-slate-800 text-xs">
                      <thead className="bg-slate-950/60 text-left font-semibold">
                        <tr>
                          {previewData.headers.map((h: string) => (
                            <th key={h} className="px-3 py-2 text-slate-300 font-bold whitespace-nowrap">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/50 bg-slate-950/20">
                        {previewData.data.map((row: any, idx: number) => (
                          <tr key={idx} className="hover:bg-slate-800/20">
                            {previewData.headers.map((h: string) => (
                              <td key={h} className="px-3 py-2 whitespace-nowrap">{row[h] !== null ? String(row[h]) : '-'}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-4 text-xs text-slate-500">Failed to render preview.</div>
                )}
              </div>

            </div>
          ) : (
            <div className={`p-8 rounded-3xl text-center text-slate-400 flex flex-col items-center justify-center h-full min-h-[400px] ${
              theme === 'dark' ? 'glass-card' : 'glass-card-light'
            }`}>
              <Database className="w-16 h-16 text-slate-600 mb-3 animate-pulse-slow" />
              <p className="font-bold text-sm">Select Dataset for Auditing</p>
              <p className="text-xs mt-1 max-w-[280px]">Choose a dataset from the list to display statistical profiles, column previews, duplicate listings, and quality matrices.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
