import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { 
  Settings, Users, ShieldAlert, Activity, Database, CheckCircle, RefreshCw 
} from 'lucide-react';
import api from '../services/api';

export const AdminPanel: React.FC = () => {
  const { theme } = useTheme();
  const [users, setUsers] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAdminData = async () => {
    try {
      // Mock fetching audit logs or active users
      const usersRes = await api.get('/auth/me'); // Simple validation call
      setUsers([
        { id: 1, username: 'admin', email: 'admin@aquasafe.ai', role: 'admin', status: 'Active' },
        { id: 2, username: 'researcher', email: 'researcher@aquasafe.ai', role: 'researcher', status: 'Active' },
        { id: 3, username: 'analyst', email: 'analyst@aquasafe.ai', role: 'analyst', status: 'Active' }
      ]);
      setLogs([
        { id: 1, action: 'USER_LOGIN', user: 'admin', time: new Date().toLocaleTimeString(), details: 'JWT signature matched successfully' },
        { id: 2, action: 'MODEL_TRAIN', user: 'researcher', time: '10:14 AM', details: 'RandomForest model generated and saved to ./saved_models' },
        { id: 3, action: 'ALERT_RESOLVE', user: 'analyst', time: '09:42 AM', details: 'Resolved Station Alpha High Risk warning' }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      {/* System diagnostics row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`p-5 rounded-2xl shadow-xl flex items-center justify-between ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">API Service Status</span>
            <h3 className="text-xl font-bold text-teal-400 mt-0.5 flex items-center gap-1.5"><CheckCircle className="w-5 h-5" /> Online</h3>
          </div>
          <Activity className="w-8 h-8 text-teal-500/20" />
        </div>
        <div className={`p-5 rounded-2xl shadow-xl flex items-center justify-between ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Telemetry DB</span>
            <h3 className="text-xl font-bold mt-0.5">PostgreSQL</h3>
          </div>
          <Database className="w-8 h-8 text-sky-500/20" />
        </div>
        <div className={`p-5 rounded-2xl shadow-xl flex items-center justify-between ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">Security clearance</span>
            <h3 className="text-xl font-bold mt-0.5">HS256 JWT</h3>
          </div>
          <Settings className="w-8 h-8 text-purple-500/20" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* User list */}
        <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><Users className="w-5 h-5 text-teal-400" /> Platform Accounts</h4>
          
          <div className="overflow-x-auto border border-slate-800 rounded-2xl">
            <table className="min-w-full divide-y divide-slate-800 text-xs text-left">
              <thead className="bg-slate-950/60 font-semibold text-slate-300">
                <tr>
                  <th className="px-4 py-2">Username</th>
                  <th className="px-4 py-2">Role</th>
                  <th className="px-4 py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 bg-slate-950/20">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-800/10">
                    <td className="px-4 py-3 font-semibold">{u.username}</td>
                    <td className="px-4 py-3 uppercase text-teal-400 font-bold">{u.role}</td>
                    <td className="px-4 py-3">{u.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Audit Logs */}
        <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
          <h4 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-1.5"><ShieldAlert className="w-5 h-5 text-sky-400" /> Platform Audit Trail</h4>
          
          <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
            {logs.map(log => (
              <div key={log.id} className="p-3 bg-slate-950/30 border border-slate-800/60 rounded-xl flex items-start justify-between">
                <div>
                  <span className="text-[9px] font-bold text-teal-400 mr-2">{log.action}</span>
                  <span className="text-[9px] text-slate-500">{log.time}</span>
                  <p className="text-xs text-slate-300 mt-1 leading-snug">{log.details}</p>
                </div>
                <span className="text-[10px] text-slate-400 italic">by {log.user}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
