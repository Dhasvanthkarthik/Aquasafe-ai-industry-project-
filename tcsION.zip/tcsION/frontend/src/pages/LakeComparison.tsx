import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { Columns, ArrowRight, Droplets, RefreshCw } from 'lucide-react';
import api from '../services/api';

export const LakeComparison: React.FC = () => {
  const { theme } = useTheme();
  
  const [lakes, setLakes] = useState<any[]>([]);
  const [lakeAId, setLakeAId] = useState<number | ''>('');
  const [lakeBId, setLakeBId] = useState<number | ''>('');
  
  const [lakeA, setLakeA] = useState<any>(null);
  const [lakeB, setLakeB] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [lakesRes, predsRes] = await Promise.all([
          api.get('/lakes'),
          api.get('/predictions/history')
        ]);
        
        const preds = predsRes.data;
        const mapped = lakesRes.data.map((l: any) => {
          const lPreds = preds.filter((p: any) => p.lake_id === l.id);
          return {
            ...l,
            latest: lPreds.length > 0 ? lPreds[0] : null
          };
        });
        
        setLakes(mapped);
        if (mapped.length > 1) {
          setLakeAId(mapped[0].id);
          setLakeBId(mapped[1].id);
          setLakeA(mapped[0]);
          setLakeB(mapped[1]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleCompare = () => {
    const a = lakes.find(l => l.id === Number(lakeAId));
    const b = lakes.find(l => l.id === Number(lakeBId));
    setLakeA(a || null);
    setLakeB(b || null);
  };

  if (loading) {
    return (
      <div className="h-[calc(100vh-4rem)] w-full flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500 mb-2"></div>
        <span className="text-sm ml-2">Loading Lake Comparison Studio...</span>
      </div>
    );
  }

  // Format Recharts data comparing the two lakes' nutrients
  const barData = [
    {
      name: 'Temp (°C)',
      [lakeA?.name || 'Lake A']: lakeA?.latest?.temperature || 0,
      [lakeB?.name || 'Lake B']: lakeB?.latest?.temperature || 0
    },
    {
      name: 'pH Level',
      [lakeA?.name || 'Lake A']: lakeA?.latest?.ph || 0,
      [lakeB?.name || 'Lake B']: lakeB?.latest?.ph || 0
    },
    {
      name: 'Dissolved Oxygen (mg/L)',
      [lakeA?.name || 'Lake A']: lakeA?.latest?.dissolved_oxygen || 0,
      [lakeB?.name || 'Lake B']: lakeB?.latest?.dissolved_oxygen || 0
    },
    {
      name: 'Phosphorus (mg/L * 10)',
      [lakeA?.name || 'Lake A']: (lakeA?.latest?.phosphorus || 0) * 10,
      [lakeB?.name || 'Lake B']: (lakeB?.latest?.phosphorus || 0) * 10
    }
  ];

  return (
    <div className={`p-6 space-y-6 transition-all ${theme === 'dark' ? 'text-slate-100' : 'text-slate-800'}`}>
      
      {/* Selection row */}
      <div className={`p-5 rounded-2xl shadow-xl flex flex-col md:flex-row items-center gap-4 ${
        theme === 'dark' ? 'glass-card' : 'glass-card-light'
      }`}>
        <div className="flex-1 w-full">
          <label className="block text-xs font-semibold text-slate-400 uppercase mb-1">Lake Station A</label>
          <select 
            value={lakeAId} 
            onChange={(e) => setLakeAId(Number(e.target.value))} 
            className="w-full bg-slate-950/40 border border-slate-800/80 p-2.5 rounded-xl text-sm"
          >
            {lakes.map(l => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </div>

        <ArrowRight className="w-5 h-5 text-slate-500 shrink-0 hidden md:block" />

        <div className="flex-1 w-full">
          <label className="block text-xs font-semibold text-slate-400 uppercase mb-1">Lake Station B</label>
          <select 
            value={lakeBId} 
            onChange={(e) => setLakeBId(Number(e.target.value))} 
            className="w-full bg-slate-950/40 border border-slate-800/80 p-2.5 rounded-xl text-sm"
          >
            {lakes.map(l => (
              <option key={l.id} value={l.id} disabled={l.id === Number(lakeAId)}>{l.name}</option>
            ))}
          </select>
        </div>

        <button 
          onClick={handleCompare}
          className="w-full md:w-auto bg-teal-600 hover:bg-teal-500 text-white font-bold px-6 py-2.5 rounded-xl transition-all cursor-pointer shadow-md self-end shrink-0"
        >
          Compare
        </button>
      </div>

      {lakeA && lakeB ? (
        <>
          {/* Side by Side details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Lake A Card */}
            <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
              <div>
                <span className="text-[10px] text-teal-400 font-bold uppercase tracking-wider block">Station Alpha</span>
                <h3 className="text-2xl font-black mt-0.5">{lakeA.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Location code: {lakeA.location_code}</p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400">Predicted Risk</span>
                  <p className={`text-base font-bold uppercase ${
                    lakeA.latest?.health_risk === 'High' ? 'text-red-500' : (lakeA.latest?.health_risk === 'Moderate' ? 'text-yellow-500' : 'text-green-500')
                  }`}>{lakeA.latest?.health_risk || 'Low'} Risk</p>
                </div>
                <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400">Station coordinates</span>
                  <p className="text-xs font-semibold mt-0.5">{lakeA.latitude.toFixed(3)}, {lakeA.longitude.toFixed(3)}</p>
                </div>
              </div>
            </div>

            {/* Lake B Card */}
            <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
              <div>
                <span className="text-[10px] text-teal-400 font-bold uppercase tracking-wider block">Station Beta</span>
                <h3 className="text-2xl font-black mt-0.5">{lakeB.name}</h3>
                <p className="text-xs text-slate-400 mt-0.5">Location code: {lakeB.location_code}</p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400">Predicted Risk</span>
                  <p className={`text-base font-bold uppercase ${
                    lakeB.latest?.health_risk === 'High' ? 'text-red-500' : (lakeB.latest?.health_risk === 'Moderate' ? 'text-yellow-500' : 'text-green-500')
                  }`}>{lakeB.latest?.health_risk || 'Low'} Risk</p>
                </div>
                <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400">Station coordinates</span>
                  <p className="text-xs font-semibold mt-0.5">{lakeB.latitude.toFixed(3)}, {lakeB.longitude.toFixed(3)}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Graphical comparison bar chart */}
          <div className={`p-6 rounded-3xl shadow-xl ${theme === 'dark' ? 'glass-card' : 'glass-card-light'}`}>
            <h4 className="text-sm font-bold uppercase tracking-wider mb-6 flex items-center gap-1.5"><Columns className="w-5 h-5 text-teal-400" /> Parameter Side-by-Side Comparison Chart</h4>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="name" stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={10} />
                  <YAxis stroke={theme === 'dark' ? '#94a3b8' : '#475569'} fontSize={10} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey={lakeA.name} fill="#0d9488" radius={[4, 4, 0, 0]} />
                  <Bar dataKey={lakeB.name} fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-16 text-slate-400 text-sm">
          A minimum of 2 lake stations must be registered to run comparisons.
        </div>
      )}

    </div>
  );
};
