import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { 
  LayoutDashboard, 
  Database, 
  Cpu, 
  Compass, 
  Map, 
  Bell, 
  MessageSquare, 
  Settings, 
  LogOut, 
  Menu, 
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Activity,
  Layers,
  Columns
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const { user, logout, isResearcher, isAdmin } = useAuth();
  const { theme } = useTheme();
  
  const navItems = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard, role: 'guest' },
    { to: '/map', label: 'GIS Risk Map', icon: Map, role: 'guest' },
    { to: '/predictions', label: 'Risk Predictor', icon: Compass, role: 'guest' },
    { to: '/forecast', label: 'Forecast Studio', icon: TrendingUp, role: 'guest' },
    { to: '/compare', label: 'Lake Comparison', icon: Columns, role: 'guest' },
    { to: '/twin', label: 'Digital Twin', icon: Activity, role: 'guest' },
    { to: '/datasets', label: 'Dataset Manager', icon: Database, role: 'researcher' },
    { to: '/models', label: 'Model Studio', icon: Cpu, role: 'researcher' },
    { to: '/chatbot', label: 'AI Eco-Assistant', icon: MessageSquare, role: 'guest' },
    { to: '/alerts', label: 'Alert Center', icon: Bell, role: 'guest' },
    { to: '/admin', label: 'Admin Console', icon: Settings, role: 'admin' },
  ];

  const handleLogout = () => {
    logout();
  };

  // Filter items by role
  const filteredItems = navItems.filter(item => {
    if (item.role === 'admin') return isAdmin;
    if (item.role === 'researcher') return isResearcher;
    return true;
  });

  return (
    <aside className={`fixed top-0 left-0 z-40 h-screen transition-all duration-300 ${isOpen ? 'w-64' : 'w-20'} 
      ${theme === 'dark' ? 'bg-slate-900/90 border-r border-slate-800 text-slate-100' : 'bg-white/90 border-r border-slate-200 text-slate-800'} 
      backdrop-blur-md flex flex-col justify-between`}
    >
      <div>
        {/* Sidebar Header / Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/10">
          <div className="flex items-center gap-2 overflow-hidden">
            <span className="text-2xl">💧</span>
            {isOpen && (
              <span className="font-extrabold text-lg bg-gradient-to-r from-teal-400 to-sky-400 bg-clip-text text-transparent whitespace-nowrap">
                AquaSafe AI
              </span>
            )}
          </div>
          <button 
            onClick={() => setIsOpen(!isOpen)} 
            className="p-1.5 rounded-lg hover:bg-slate-800/10 dark:hover:bg-slate-700/30 cursor-pointer"
          >
            {isOpen ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          </button>
        </div>

        {/* Navigation list */}
        <nav className="mt-4 px-3 space-y-1">
          {filteredItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `
                flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 cursor-pointer group
                ${isActive 
                  ? 'bg-teal-600 text-white font-medium shadow-md shadow-teal-600/20' 
                  : 'hover:bg-slate-800/10 dark:hover:bg-slate-800/50 hover:text-teal-400 text-slate-400'
                }
              `}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              {isOpen && <span className="text-sm font-medium transition-opacity duration-300">{item.label}</span>}
              {!isOpen && (
                <div className="absolute left-20 ml-2 px-2 py-1 bg-slate-900 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-150 whitespace-nowrap z-50">
                  {item.label}
                </div>
              )}
            </NavLink>
          ))}
        </nav>
      </div>

      {/* User profile & Logout */}
      <div className="p-3 border-t border-slate-800/10 dark:border-slate-800">
        {isOpen && user && (
          <div className="mb-3 px-3 py-2 bg-slate-800/10 dark:bg-slate-800/30 rounded-xl flex flex-col">
            <span className="font-semibold text-xs text-teal-400 uppercase tracking-wider">{user.role}</span>
            <span className="text-sm font-medium truncate">{user.username}</span>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-red-500/10 hover:text-red-400 text-slate-400 transition-all duration-200 cursor-pointer group"
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {isOpen && <span className="text-sm font-medium">Log Out</span>}
        </button>
      </div>
    </aside>
  );
};
