import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { Sun, Moon, Bell, ShieldAlert, Check } from 'lucide-react';
import api from '../services/api';

export const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const location = useLocation();
  const [alerts, setAlerts] = useState<any[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const res = await api.get('/alerts?is_resolved=false');
        setAlerts(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    if (user) {
      fetchAlerts();
      // Poll alerts every 30 seconds
      const interval = setInterval(fetchAlerts, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const resolveAlert = async (id: number) => {
    try {
      await api.put(`/alerts/${id}/resolve`);
      setAlerts(prev => prev.filter(a => a.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const getPageTitle = () => {
    switch (location.pathname) {
      case '/': return 'Analytics Dashboard';
      case '/map': return 'GIS Spatial Risk Map';
      case '/predictions': return 'AI Risk Predictor';
      case '/forecast': return 'Forecast Studio';
      case '/compare': return 'Lake Comparison';
      case '/twin': return 'Lake Digital Twin';
      case '/datasets': return 'Dataset Management';
      case '/models': return 'Model Registry & Studio';
      case '/chatbot': return 'AI Research Assistant';
      case '/alerts': return 'Alert Center';
      case '/admin': return 'Admin Panel';
      default: return 'AquaSafe AI';
    }
  };

  return (
    <header className={`h-16 flex items-center justify-between px-6 border-b z-30 transition-all duration-300
      ${theme === 'dark' ? 'bg-slate-950/80 border-slate-800 text-slate-100' : 'bg-slate-50/80 border-slate-200 text-slate-800'} 
      backdrop-blur-md sticky top-0`}
    >
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-bold tracking-tight">{getPageTitle()}</h1>
      </div>

      <div className="flex items-center gap-4">
        {/* Alerts Notification dropdown */}
        {user && (
          <div className="relative">
            <button 
              onClick={() => setShowDropdown(!showDropdown)}
              className="p-2 rounded-xl hover:bg-slate-800/10 dark:hover:bg-slate-800/40 relative cursor-pointer"
            >
              <Bell className="w-5 h-5" />
              {alerts.length > 0 && (
                <span className="absolute top-1.5 right-1.5 bg-red-500 text-white text-[10px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center animate-pulse">
                  {alerts.length}
                </span>
              )}
            </button>

            {showDropdown && (
              <div className="absolute right-0 mt-3 w-80 rounded-2xl glass-card bg-slate-900 border border-slate-800 shadow-2xl p-4 z-50 text-slate-100">
                <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
                  <span className="font-semibold text-sm flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-red-400" /> Active System Warnings
                  </span>
                  <span className="text-xs text-slate-400">{alerts.length} Warnings</span>
                </div>
                
                <div className="space-y-2.5 max-h-60 overflow-y-auto">
                  {alerts.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      No active alerts. All lakes reporting clear.
                    </div>
                  ) : (
                    alerts.map((alert) => (
                      <div key={alert.id} className="p-2.5 bg-slate-950/50 border border-slate-800 rounded-xl flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <p className="text-xs text-red-400 font-bold mb-0.5">High Risk Detected</p>
                          <p className="text-xs text-slate-300 leading-snug">{alert.message}</p>
                        </div>
                        <button 
                          onClick={() => resolveAlert(alert.id)}
                          className="p-1 rounded bg-teal-600/20 text-teal-400 hover:bg-teal-600 hover:text-white transition-colors cursor-pointer"
                          title="Acknowledge & Resolve Alert"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-xl hover:bg-slate-800/10 dark:hover:bg-slate-800/40 text-slate-400 hover:text-teal-400 transition-all duration-200 cursor-pointer"
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? <Sun className="w-5 h-5 text-teal-400" /> : <Moon className="w-5 h-5 text-slate-700" />}
        </button>

        {/* User indicator (Desktop only) */}
        {user && (
          <div className="hidden md:flex items-center gap-2 border-l border-slate-800/10 dark:border-slate-800 pl-4">
            <div className="w-8 h-8 rounded-full bg-teal-600 flex items-center justify-center font-bold text-white text-sm select-none">
              {user.username.substring(0, 2).toUpperCase()}
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-semibold text-slate-400 leading-none">{user.role}</span>
              <span className="text-sm font-medium">{user.username}</span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
