# AquaSafe AI – Cyanobacterial Bloom & Public Health Risk Platform

AquaSafe AI is an enterprise-grade, production-ready full-stack environmental intelligence platform designed to predict cyanobacterial bloom severity and associated public health risks using Machine Learning. 

It provides real-time environmental forecasts, interactive GIS mapping, predictive "What-If" simulations, AI explainability (SHAP), and an AI research chatbot assistant.

---

## 🚀 Quick Start (Docker Compose)

Spin up the entire system (FastAPI backend, React frontend, PostgreSQL database, and Redis cache) with a single command:

```bash
docker compose up --build -d
```

Once running:
- **Frontend Panel**: `http://localhost:3000`
- **FastAPI Documentation**: `http://localhost:8000/docs`
- **PostgreSQL Database**: `localhost:5432`

### Seeding the Dashboard Data
To pre-populate the lakes, users, and 15 days of historical prediction logs:
```bash
docker compose exec backend python app/seed.py
```

---

## 🛠️ Tech Stack & Architecture

### Backend Engine
- **FastAPI (Python)**: High-performance asynchronous REST endpoints.
- **SQLAlchemy ORM**: Flexible schema management with PostgreSQL (prod) and SQLite (dev fallback).
- **Machine Learning Pipeline**: Custom preprocessors and feature generators using Scikit-Learn, XGBoost, CatBoost, and LightGBM.
- **Explainable AI (XAI)**: SHAP tree explainers and custom local perturbation calculators for deep neural network support.
- **Open-Meteo Integration**: Live weather retrieval and 30-day forecast inputs.

### Frontend App
- **React 19 + TypeScript**: Modular component hierarchy.
- **Tailwind CSS v4**: Utility-first styling with modern glassmorphism panels.
- **Framer Motion**: Smooth micro-animations.
- **Recharts**: Beautiful analytics trends, risk distribution pies, and SHAP contribution bars.
- **React Leaflet**: Interactive GIS coordinate maps.

---

## 📂 Project Structure

```text
aquasafe-ai/
├── backend/
│   ├── app/
│   │   ├── core/
│   │   │   ├── config.py         # App settings & API keys
│   │   │   └── security.py       # Password hashes & JWT keys
│   │   ├── ml/
│   │   │   ├── preprocessing.py  # Outlier detection, standardizing
│   │   │   ├── engineering.py    # Nutrient indexes & NP ratio calculators
│   │   │   ├── model_studio.py   # Training & metrics comparisons
│   │   │   └── explainability.py # SHAP value engine
│   │   ├── models/
│   │   │   └── database.py       # SQLAlchemy schemas (Users, Predictions, Lakes)
│   │   ├── routers/              # REST controllers
│   │   ├── services/
│   │   │   ├── weather.py        # Open-Meteo API wrapper
│   │   │   └── reports.py        # PDF & Excel exporters
│   │   ├── main.py               # App entry point
│   │   └── seed.py               # Database populator & CSV creator
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/           # Navigation, sidebars, private route gates
│   │   ├── context/              # Dark theme, JWT Auth contexts
│   │   ├── pages/                # Dashboards, Maps, Predictors, Studio
│   │   ├── services/
│   │   │   └── api.ts            # Axios instances
│   │   ├── App.tsx               # Route mapping
│   │   └── main.tsx
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
└── docker-compose.yml
```

---

## 🔒 User Roles & Accounts

Seeded credentials (from `python app/seed.py`):
1. **Admin**:
   - Username: `admin` | Password: `admin123`
   - Role: `admin` (Can delete models, manage users, audit logs)
2. **Researcher**:
   - Username: `researcher` | Password: `researcher123`
   - Role: `researcher` (Can upload datasets, trigger model training)
3. **Analyst**:
   - Username: `analyst` | Password: `analyst123`
   - Role: `analyst` (Can run manual predictions & simulation parameters)

---

## 🧪 Running the Test Suite

Validate endpoints and data mapping:
```bash
cd backend
python -m pytest
```
