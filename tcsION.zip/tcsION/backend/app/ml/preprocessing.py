import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from typing import Dict, Any, Tuple, List

class DataPreprocessor:
    def __init__(self, scaling_type: str = "standard"):
        self.scaling_type = scaling_type
        self.scalers: Dict[str, Any] = {}
        self.encoders: Dict[str, LabelEncoder] = {}
        self.impute_values: Dict[str, float] = {}
        self.numerical_cols: List[str] = []
        self.categorical_cols: List[str] = []
        self.is_fitted = False

    def get_data_quality_report(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Generates a complete data quality and statistics report."""
        row_count = len(df)
        col_count = len(df.columns)
        missing_count = int(df.isnull().sum().sum())
        duplicate_count = int(df.duplicated().sum())
        
        # Outliers check using IQR
        outliers_total = 0
        stats = {}
        
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                col_missing = int(df[col].isnull().sum())
                q1 = df[col].quantile(0.25)
                q3 = df[col].quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                col_outliers = int(((df[col] < lower_bound) | (df[col] > upper_bound)).sum())
                outliers_total += col_outliers
                
                stats[col] = {
                    "mean": float(df[col].mean()) if not pd.isna(df[col].mean()) else 0.0,
                    "median": float(df[col].median()) if not pd.isna(df[col].median()) else 0.0,
                    "std": float(df[col].std()) if not pd.isna(df[col].std()) else 0.0,
                    "min": float(df[col].min()) if not pd.isna(df[col].min()) else 0.0,
                    "max": float(df[col].max()) if not pd.isna(df[col].max()) else 0.0,
                    "outliers": col_outliers,
                    "missing": col_missing
                }
            else:
                col_missing = int(df[col].isnull().sum())
                stats[col] = {
                    "unique_values": int(df[col].nunique()),
                    "missing": col_missing,
                    "top_value": str(df[col].mode().iloc[0]) if len(df[col].mode()) > 0 else "N/A"
                }

        # Calculate a simple Quality Score
        quality_score = 100.0
        if row_count > 0:
            missing_pct = missing_count / (row_count * col_count)
            duplicate_pct = duplicate_count / row_count
            outliers_pct = outliers_total / (row_count * (len(stats) or 1))
            quality_score = max(0.0, 100.0 - (missing_pct * 100.0) - (duplicate_pct * 50.0) - (outliers_pct * 10.0))

        return {
            "row_count": row_count,
            "col_count": col_count,
            "missing_count": missing_count,
            "duplicate_count": duplicate_count,
            "outlier_count": outliers_total,
            "data_quality_score": round(quality_score, 2),
            "stats": stats
        }

    def fit(self, df: pd.DataFrame, target_col: str = None) -> "DataPreprocessor":
        """Fits the scaling, imputation and encoding configurations on the training set."""
        df_copy = df.copy()
        
        # Determine numerical and categorical columns
        self.numerical_cols = []
        self.categorical_cols = []
        
        for col in df_copy.columns:
            if col == target_col:
                continue
            if pd.api.types.is_numeric_dtype(df_copy[col]):
                self.numerical_cols.append(col)
                # Compute median for imputation
                self.impute_values[col] = float(df_copy[col].median())
            else:
                self.categorical_cols.append(col)
                # Compute mode for imputation
                mode_val = df_copy[col].mode()
                self.impute_values[col] = str(mode_val.iloc[0]) if len(mode_val) > 0 else "Unknown"

        # Fit Scalers
        for col in self.numerical_cols:
            if self.scaling_type == "standard":
                scaler = StandardScaler()
            else:
                scaler = MinMaxScaler()
            
            # Temporary imputation for fitting the scaler
            non_null_vals = df_copy[col].fillna(self.impute_values[col]).values.reshape(-1, 1)
            scaler.fit(non_null_vals)
            self.scalers[col] = scaler

        # Fit Label Encoders
        for col in self.categorical_cols:
            le = LabelEncoder()
            # Feed filled series
            filled_series = df_copy[col].fillna(self.impute_values[col]).astype(str)
            le.fit(filled_series)
            self.encoders[col] = le

        self.is_fitted = True
        return self

    def transform(self, df: pd.DataFrame, target_col: str = None) -> pd.DataFrame:
        """Transforms a dataset using the fitted config (handles imputation, encoding, and scaling)."""
        if not self.is_fitted:
            raise ValueError("Preprocessor has not been fitted yet.")
        
        df_copy = df.copy()
        
        # Impute missing values
        for col, val in self.impute_values.items():
            if col in df_copy.columns:
                df_copy[col] = df_copy[col].fillna(val)

        # Scale numerical features
        for col in self.numerical_cols:
            if col in df_copy.columns:
                df_copy[col] = self.scalers[col].transform(df_copy[col].values.reshape(-1, 1)).flatten()

        # Encode categorical features
        for col in self.categorical_cols:
            if col in df_copy.columns:
                # Handle unseen labels by mapping them to the mode class
                le = self.encoders[col]
                classes = set(le.classes_)
                df_copy[col] = df_copy[col].apply(lambda x: str(x) if str(x) in classes else self.impute_values[col])
                df_copy[col] = le.transform(df_copy[col])

        return df_copy

    def save(self, filepath: str):
        """Serializes the processor using joblib."""
        joblib.dump(self, filepath)

    @classmethod
    def load(cls, filepath: str) -> "DataPreprocessor":
        """Loads a processor from a joblib file."""
        return joblib.load(filepath)
