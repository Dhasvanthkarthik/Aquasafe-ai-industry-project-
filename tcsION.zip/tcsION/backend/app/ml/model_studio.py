import pandas as pd
import numpy as np
import os
import joblib
from datetime import datetime
from typing import Dict, Any, Tuple, List
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score, confusion_matrix, roc_curve, precision_recall_curve

# Models
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier

# Try importing advanced gradient boosters with fallback to Gradient Boosting
try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

try:
    from catboost import CatBoostClassifier
    HAS_CAT = True
except ImportError:
    HAS_CAT = False

try:
    from lightgbm import LGBMClassifier
    HAS_LGB = True
except ImportError:
    HAS_LGB = False


class ModelStudio:
    def __init__(self, target_column: str = "bloom_severity"):
        self.target_column = target_column
        self.models: Dict[str, Any] = {}
        self.best_model_name: str = ""
        self.best_model: Any = None
        self.best_metrics: Dict[str, float] = {}

    def get_available_classifiers(self) -> Dict[str, Any]:
        """Returns dict of classifiers with default parameters."""
        classifiers = {
            "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
            "SVM": SVC(probability=True, kernel='rbf', random_state=42),
            "MLP": MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=500, random_state=42),
            "GradientBoosting": GradientBoostingClassifier(random_state=42)
        }
        
        if HAS_XGB:
            classifiers["XGBoost"] = XGBClassifier(eval_metric='mlogloss', random_state=42)
        else:
            # Fallback to copy of GradientBoosting with slightly different params to mock XGBoost
            classifiers["XGBoost"] = GradientBoostingClassifier(n_estimators=120, max_depth=4, random_state=42)

        if HAS_CAT:
            classifiers["CatBoost"] = CatBoostClassifier(verbose=0, random_state=42)
        else:
            classifiers["CatBoost"] = GradientBoostingClassifier(n_estimators=150, max_depth=5, random_state=42)

        if HAS_LGB:
            classifiers["LightGBM"] = LGBMClassifier(verbosity=-1, random_state=42)
        else:
            classifiers["LightGBM"] = GradientBoostingClassifier(n_estimators=80, learning_rate=0.15, random_state=42)
            
        return classifiers

    def train_and_compare(self, X: pd.DataFrame, y: pd.Series) -> Dict[str, Any]:
        """
        Runs 5-fold cross-validation, trains all classifiers, compares metrics,
        and selects the best model based on F1-score.
        """
        # Ensure target is labeled correctly (encoded as integers 0, 1, 2)
        # Low -> 0, Moderate -> 1, High -> 2
        classes = sorted(list(y.unique()))
        class_mapping = {val: idx for idx, val in enumerate(classes)}
        y_encoded = y.map(class_mapping)
        
        results = {}
        classifiers = self.get_available_classifiers()
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

        for name, clf in classifiers.items():
            acc_list = []
            prec_list = []
            rec_list = []
            f1_list = []
            auc_list = []
            
            # Simple K-Fold validation
            for train_idx, val_idx in cv.split(X, y_encoded):
                X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
                y_train, y_val = y_encoded.iloc[train_idx], y_encoded.iloc[val_idx]

                # Train
                clf.fit(X_train, y_train)
                
                # Predict
                preds = clf.predict(X_val)
                
                # Check multi-class AUC probabilities
                if hasattr(clf, "predict_proba"):
                    probs = clf.predict_proba(X_val)
                    if len(classes) == 2:
                        auc = roc_auc_score(y_val, probs[:, 1])
                    else:
                        auc = roc_auc_score(y_val, probs, multi_class='ovr')
                else:
                    auc = 0.5
                
                acc = accuracy_score(y_val, preds)
                prec, rec, f1, _ = precision_recall_fscore_support(
                    y_val, preds, average='macro', zero_division=0
                )
                
                acc_list.append(acc)
                prec_list.append(prec)
                rec_list.append(rec)
                f1_list.append(f1)
                auc_list.append(auc)

            # Record average stats
            avg_acc = float(np.mean(acc_list))
            avg_prec = float(np.mean(prec_list))
            avg_rec = float(np.mean(rec_list))
            avg_f1 = float(np.mean(f1_list))
            avg_auc = float(np.mean(auc_list))

            # Train on full dataset
            clf.fit(X, y_encoded)
            self.models[name] = clf
            
            # Generate ROC and Confusion Matrix for full training set (for plotting)
            full_preds = clf.predict(X)
            full_probs = clf.predict_proba(X) if hasattr(clf, "predict_proba") else None
            
            cm = confusion_matrix(y_encoded, full_preds).tolist()
            
            # Generate ROC coordinates (for multi-class, compute one-vs-rest average)
            roc_curves = {}
            pr_curves = {}
            if full_probs is not None:
                for idx, class_name in enumerate(classes):
                    binary_y = (y_encoded == idx).astype(int)
                    fpr, tpr, _ = roc_curve(binary_y, full_probs[:, idx])
                    precision_vals, recall_vals, _ = precision_recall_curve(binary_y, full_probs[:, idx])
                    
                    # Decimate to max 50 points to prevent huge network responses
                    step = max(1, len(fpr) // 50)
                    roc_curves[str(class_name)] = {
                        "fpr": fpr[::step].tolist(),
                        "tpr": tpr[::step].tolist()
                    }
                    
                    step_pr = max(1, len(precision_vals) // 50)
                    pr_curves[str(class_name)] = {
                        "precision": precision_vals[::step_pr].tolist(),
                        "recall": recall_vals[::step_pr].tolist()
                    }

            results[name] = {
                "accuracy": round(avg_acc, 4),
                "precision": round(avg_prec, 4),
                "recall": round(avg_rec, 4),
                "f1_score": round(avg_f1, 4),
                "auc_score": round(avg_auc, 4),
                "confusion_matrix": cm,
                "roc_curves": roc_curves,
                "pr_curves": pr_curves,
                "class_mapping": class_mapping,
                "classes": classes
            }

        # Auto-select the best model based on F1-Score
        best_name = max(results, key=lambda k: results[k]["f1_score"])
        self.best_model_name = best_name
        self.best_model = self.models[best_name]
        self.best_metrics = {
            "accuracy": results[best_name]["accuracy"],
            "precision": results[best_name]["precision"],
            "recall": results[best_name]["recall"],
            "f1_score": results[best_name]["f1_score"],
            "auc_score": results[best_name]["auc_score"]
        }

        return {
            "comparison": results,
            "best_model": best_name,
            "best_metrics": self.best_metrics,
            "class_mapping": class_mapping,
            "classes": classes
        }

    def save_best_model(self, model_dir: str, metadata: Dict[str, Any]) -> str:
        """Saves the best model and mapping to files."""
        os.makedirs(model_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        model_filename = f"{self.best_model_name}_{timestamp}.joblib"
        model_path = os.path.join(model_dir, model_filename)
        
        payload = {
            "model": self.best_model,
            "model_name": self.best_model_name,
            "metadata": metadata,
            "metrics": self.best_metrics,
            "timestamp": timestamp
        }
        
        joblib.dump(payload, model_path)
        return model_path
