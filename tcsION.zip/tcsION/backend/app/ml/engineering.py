import pandas as pd
import numpy as np
from typing import Dict, Any, Union

def calculate_derived_features(data: Union[pd.DataFrame, Dict[str, Any]]) -> Union[pd.DataFrame, Dict[str, Any]]:
    """
    Computes derived environmental and water quality features.
    Accepts either a pandas DataFrame (for batch processing/training)
    or a dictionary (for real-time single predictions).
    """
    if isinstance(data, pd.DataFrame):
        df = data.copy()
        
        # 1. N:P Ratio (Nitrogen to Phosphorus)
        # Avoid division by zero
        p_safe = df['phosphorus'].replace(0, 0.001)
        df['np_ratio'] = df['nitrogen'] / p_safe
        
        # 2. DO-Temperature Interaction
        df['do_temp_interaction'] = df['dissolved_oxygen'] * df['temperature']
        
        # 3. Environmental Index (average of normalised weather conditions)
        df['environmental_index'] = (df['temperature'] + df['humidity'] + df['sunlight']) / 3.0
        
        # 4. Water Quality Index (Simplified approximation)
        df['wqi'] = (df['dissolved_oxygen'] / (df['ph'].replace(0, 7.0))) * (df['nitrogen'] + df['phosphorus'])
        
        # 5. Bloom Index (Higher temp & nutrients increase bloom potential, dissolved oxygen suppresses it)
        df['bloom_index'] = (df['temperature'] * df['phosphorus']) / (df['dissolved_oxygen'] + 0.1)
        
        # 6. Health Risk Index
        df['health_risk_index'] = (df['bloom_index'] * 1.5) + (df['ph'] - 7.0).abs()
        
        # 7. Season Index
        season_map = {"Spring": 1.0, "Summer": 2.0, "Autumn": 1.5, "Winter": 0.5}
        df['season_index'] = df['season'].map(season_map).fillna(1.0)
        
        # Lags (For dataset training, mock using shifting, fallback to defaults)
        if len(df) > 1:
            df['rainfall_lag'] = df['rainfall'].shift(1).fillna(df['rainfall'].mean())
            df['temp_lag'] = df['temperature'].shift(1).fillna(df['temperature'].mean())
            df['humidity_lag'] = df['humidity'].shift(1).fillna(df['humidity'].mean())
        else:
            df['rainfall_lag'] = df['rainfall']
            df['temp_lag'] = df['temperature']
            df['humidity_lag'] = df['humidity']
            
        return df

    elif isinstance(data, dict):
        d = data.copy()
        
        # 1. N:P Ratio
        p = d.get('phosphorus', 0.0)
        p_safe = p if p > 0 else 0.001
        d['np_ratio'] = d.get('nitrogen', 0.0) / p_safe
        
        # 2. DO-Temperature Interaction
        d['do_temp_interaction'] = d.get('dissolved_oxygen', 0.0) * d.get('temperature', 0.0)
        
        # 3. Environmental Index
        d['environmental_index'] = (d.get('temperature', 0.0) + d.get('humidity', 0.0) + d.get('sunlight', 0.0)) / 3.0
        
        # 4. Water Quality Index
        ph = d.get('ph', 7.0)
        ph_safe = ph if ph > 0 else 7.0
        d['wqi'] = (d.get('dissolved_oxygen', 0.0) / ph_safe) * (d.get('nitrogen', 0.0) + d.get('phosphorus', 0.0))
        
        # 5. Bloom Index
        do = d.get('dissolved_oxygen', 0.0)
        d['bloom_index'] = (d.get('temperature', 0.0) * d.get('phosphorus', 0.0)) / (do + 0.1)
        
        # 6. Health Risk Index
        d['health_risk_index'] = (d['bloom_index'] * 1.5) + abs(ph - 7.0)
        
        # 7. Season Index
        season_map = {"Spring": 1.0, "Summer": 2.0, "Autumn": 1.5, "Winter": 0.5}
        d['season_index'] = season_map.get(d.get('season', "Spring"), 1.0)
        
        # Lags (fallback to current values for single predict if no history supplied)
        d['rainfall_lag'] = d.get('rainfall_lag', d.get('rainfall', 0.0))
        d['temp_lag'] = d.get('temp_lag', d.get('temperature', 0.0))
        d['humidity_lag'] = d.get('humidity_lag', d.get('humidity', 0.0))
        
        return d
    
    else:
        raise ValueError("Unsupported data format for feature engineering.")
