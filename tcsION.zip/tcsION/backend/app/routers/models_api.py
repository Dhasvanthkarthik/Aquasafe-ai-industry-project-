import os
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.database import ModelRegistry, Dataset, AuditLog
from app.schemas.schemas import ModelRegistryResponse
from app.routers.auth import check_user_role
from app.ml.preprocessing import DataPreprocessor
from app.ml.engineering import calculate_derived_features
from app.ml.model_studio import ModelStudio
import pandas as pd

router = APIRouter(prefix="/models", tags=["Model Registry"])

MODEL_DIR = "./saved_models"
os.makedirs(MODEL_DIR, exist_ok=True)

@router.get("/", response_model=List[ModelRegistryResponse])
def get_models(db: Session = Depends(get_db)):
    return db.query(ModelRegistry).order_by(ModelRegistry.created_at.desc()).all()

@router.post("/train", status_code=status.HTTP_201_CREATED)
def train_model(
    dataset_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin", "researcher"]))
):
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")
        
    if not os.path.exists(dataset.filename):
        raise HTTPException(status_code=404, detail="Physical dataset file missing on server")

    try:
        # Load dataset
        file_ext = os.path.splitext(dataset.filename)[1].lower()
        if file_ext == ".csv":
            df = pd.read_csv(dataset.filename)
        else:
            df = pd.read_excel(dataset.filename)

        # 1. Clean and Map columns
        from app.routers.datasets import clean_and_map_columns
        df = clean_and_map_columns(df)

        # Ensure target column is present
        target_col = "bloom_severity"
        if target_col not in df.columns:
            raise HTTPException(
                status_code=400, 
                detail=f"Dataset is missing required target column '{target_col}'"
            )

        # 2. Feature Engineering
        df_engineered = calculate_derived_features(df)

        # Ensure all columns required are present and not null
        # We will keep features
        features = [
            "temperature", "ph", "rainfall", "humidity", "wind_speed", "sunlight",
            "dissolved_oxygen", "conductivity", "bod", "nitrogen", "phosphorus",
            "season_index", "np_ratio", "do_temp_interaction", "environmental_index",
            "wqi", "bloom_index", "health_risk_index", "rainfall_lag", "temp_lag", "humidity_lag"
        ]
        
        # Verify features present
        missing_feats = [f for f in features if f not in df_engineered.columns]
        if missing_feats:
            # If lags aren't pre-computed, fallback/mock
            for f in missing_feats:
                df_engineered[f] = 0.0

        # Fit preprocessor
        preprocessor = DataPreprocessor(scaling_type="standard")
        preprocessor.fit(df_engineered[features + [target_col]], target_col=target_col)
        
        # Save preprocessor pipeline
        preprocessor_path = os.path.join(MODEL_DIR, f"preprocessor_{dataset_id}.joblib")
        preprocessor.save(preprocessor_path)

        # Transform data
        X_df = df_engineered[features]
        X_trans = preprocessor.transform(X_df)
        y = df_engineered[target_col]

        # 3. Model Studio Comparison
        studio = ModelStudio(target_column=target_col)
        comparison_results = studio.train_and_compare(X_trans, y)

        # 4. Save best model package
        metadata = {
            "dataset_id": dataset.id,
            "dataset_name": dataset.name,
            "features": features,
            "preprocessor_path": preprocessor_path,
            "trained_by": current_user.username,
            "class_mapping": comparison_results["class_mapping"],
            "classes": comparison_results["classes"]
        }
        
        model_file_path = studio.save_best_model(MODEL_DIR, metadata)

        # 5. Save all trained model entries to DB
        created_entries = []
        for name, metrics in comparison_results["comparison"].items():
            # Get latest version for this model type
            max_version = db.query(ModelRegistry).filter(ModelRegistry.model_type == name).count()
            version = max_version + 1
            
            is_best = (name == comparison_results["best_model"])
            
            db_model = ModelRegistry(
                name=f"{name} v{version}",
                version=version,
                model_type=name,
                accuracy=metrics["accuracy"],
                f1_score=metrics["f1_score"],
                precision_score=metrics["precision"],
                recall_score=metrics["recall"],
                auc_score=metrics["auc_score"],
                is_active=is_best, # Best model defaults to active
                parameters_json=metadata,
                metrics_history_json=metrics,
                file_path=model_file_path if is_best else "" # Save path for best model
            )
            
            # Deactivate previous active models if this one becomes active
            if is_best:
                db.query(ModelRegistry).filter(ModelRegistry.is_active == True).update({"is_active": False})
                
            db.add(db_model)
            created_entries.append(db_model)
            
        db.commit()

        # Audit Log
        audit = AuditLog(
            user_id=current_user.id, 
            action="MODEL_TRAIN", 
            details=f"Trained models on dataset {dataset.name}. Best model: {comparison_results['best_model']}"
        )
        db.add(audit)
        db.commit()

        return {
            "message": f"Successfully trained models. Best model: {comparison_results['best_model']}",
            "best_model": comparison_results["best_model"],
            "best_metrics": comparison_results["best_metrics"]
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Model training pipeline failed: {str(e)}"
        )

@router.put("/{model_id}/activate")
def activate_model(
    model_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_role:=check_user_role(["admin", "researcher"]))
):
    model = db.query(ModelRegistry).filter(ModelRegistry.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
        
    if not model.file_path:
        raise HTTPException(
            status_code=400, 
            detail="Cannot activate this specific model because it was not saved. Only the top-performing model of each training cycle is saved to disk."
        )

    # Deactivate all models
    db.query(ModelRegistry).filter(ModelRegistry.is_active == True).update({"is_active": False})
    
    # Activate this one
    model.is_active = True
    db.commit()
    
    # Audit log
    audit = AuditLog(user_id=current_user.id, action="MODEL_ACTIVATE", details=f"Activated model {model.name}")
    db.add(audit)
    db.commit()

    return {"message": f"Activated model: {model.name}"}

@router.delete("/{model_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_model(
    model_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin"]))
):
    model = db.query(ModelRegistry).filter(ModelRegistry.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")

    # Delete model file if present
    if model.file_path and os.path.exists(model.file_path):
        try:
            os.remove(model.file_path)
            # Try to delete preprocessor
            params = model.parameters_json
            if params and "preprocessor_path" in params:
                os.remove(params["preprocessor_path"])
        except Exception:
            pass

    db.delete(model)
    db.commit()
    return None
