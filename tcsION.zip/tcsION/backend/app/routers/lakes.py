from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.database import Lake, Prediction
from app.schemas.schemas import LakeCreate, LakeResponse
from app.routers.auth import check_user_role, get_current_user

router = APIRouter(prefix="/lakes", tags=["Lakes"])

@router.get("/", response_model=List[LakeResponse])
def get_lakes(db: Session = Depends(get_db)):
    return db.query(Lake).all()

@router.post("/", response_model=LakeResponse)
def create_lake(
    lake_in: LakeCreate,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin", "researcher"]))
):
    existing = db.query(Lake).filter(Lake.name == lake_in.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Lake with this name already exists")
    
    existing_code = db.query(Lake).filter(Lake.location_code == lake_in.location_code).first()
    if existing_code:
        raise HTTPException(status_code=400, detail="Location code must be unique")

    db_lake = Lake(
        name=lake_in.name,
        latitude=lake_in.latitude,
        longitude=lake_in.longitude,
        location_code=lake_in.location_code,
        active_status=lake_in.active_status
    )
    db.add(db_lake)
    db.commit()
    db.refresh(db_lake)
    return db_lake

@router.get("/{lake_id}", response_model=LakeResponse)
def get_lake(lake_id: int, db: Session = Depends(get_db)):
    lake = db.query(Lake).filter(Lake.id == lake_id).first()
    if not lake:
        raise HTTPException(status_code=404, detail="Lake not found")
    return lake

@router.delete("/{lake_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_lake(
    lake_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin"]))
):
    lake = db.query(Lake).filter(Lake.id == lake_id).first()
    if not lake:
        raise HTTPException(status_code=404, detail="Lake not found")
    db.delete(lake)
    db.commit()
    return None
