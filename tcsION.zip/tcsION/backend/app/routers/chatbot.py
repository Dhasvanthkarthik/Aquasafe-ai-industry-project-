import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.schemas import ChatRequest, ChatResponse
from app.core.config import settings
from typing import List, Dict, Any

router = APIRouter(prefix="/chatbot", tags=["AI Research Assistant"])

# Local Ecology Knowledge Base for fallback answers
KNOWLEDGE_BASE = {
    "bloom_causes": (
        "Cyanobacterial blooms are primarily caused by eutrophication—an excess of nutrients (specifically phosphorus and nitrogen) "
        "in the water. Key environmental drivers include: 1) High temperatures (>25°C), which speed up algal growth, 2) Calm water conditions "
        "or low wind, which prevent mixing and allow buoyant cyanobacteria to float to the surface, and 3) High sunlight levels "
        "providing energy for photosynthesis. Agricultural runoff and wastewater discharges are the primary human-made nutrient sources."
    ),
    "mitigation": (
        "Remediation and preventive measures for cyanobacterial blooms include:\n"
        "- Nutrient Management: Restricting agricultural fertilizer runoff and improving wastewater treatment to lower nitrogen/phosphorus inflow.\n"
        "- Physical Controls: Installing aeration systems or ultrasonic devices to disrupt buoyancy and water stratification.\n"
        "- Chemical Controls: Using EPA-approved algaecides (such as copper sulfate) or nutrient-locking agents (like aluminum sulfate/Phoslock) to precipitate phosphorus.\n"
        "- Biological Controls: Introducing biomanipulation strategies to increase zooplankton grazing on phytoplankton."
    ),
    "shap_explain": (
        "SHAP (SHapley Additive exPlanations) values explain individual machine learning predictions by measuring how each input "
        "parameter shifts the model's output away from the base average value. The Shapley value guarantees a fair distribution of the "
        "factors. For example, if the model predicts a 'High' bloom risk, SHAP might show that the high temperature added +0.30 to the probability, "
        "elevated phosphorus added +0.25, while high dissolved oxygen reduced the risk by -0.15."
    ),
    "lime_explain": (
        "LIME (Local Interpretable Model-agnostic Explanations) builds a simple, interpretable linear model around the specific "
        "prediction instance by perturbing the input features and observing the outputs. While SHAP looks at all possible feature "
        "combinations globally, LIME fits a local boundary around a single sample, showing the approximate local weights of each factor."
    ),
    "models": (
        "AquaSafe AI compare seven models:\n"
        "- Random Forest: Ensemble of decision trees, excellent for handling non-linear relations and resistant to overfitting.\n"
        "- Gradient Boosting (XGBoost, CatBoost, LightGBM): High-performance sequential booster models that iteratively correct errors.\n"
        "- SVM (Support Vector Machine): Finds optimal boundaries between risk classes in high-dimensional space.\n"
        "- MLP (Multi-Layer Perceptron): A feed-forward neural network capable of finding deep, complex water parameter interactions."
    ),
    "do_effect": (
        "Dissolved Oxygen (DO) is a critical indicator of water health. During active blooms, cyanobacteria generate oxygen through photosynthesis "
        "during the day, causing high DO. However, at night or when the bloom collapses, massive bacteria consume oxygen to decompose "
        "the algae. This depletes DO, creating 'dead zones' (anoxia) that kill fish and collapse the ecosystem."
    ),
    "np_ratio": (
        "The N:P Ratio (Nitrogen to Phosphorus) indicates nutrient limitation. Under Redfield Ratio guidelines, a ratio below 16:1 "
        "generally suggests nitrogen limitation, which favors nitrogen-fixing cyanobacteria (like Anabaena or Aphanizomenon) because "
        "they can pull nitrogen gas from the atmosphere. Ratios above 20:1 usually indicate phosphorus limitation."
    )
}

def search_local_knowledge(query: str) -> str:
    """Keyword-based routing for local offline chat fallback."""
    q = query.lower()
    if "cause" in q or "why do blooms happen" in q:
        return KNOWLEDGE_BASE["bloom_causes"]
    elif "mitigat" in q or "prevent" in q or "control" in q or "remedi" in q:
        return KNOWLEDGE_BASE["mitigation"]
    elif "shap" in q or "explainability" in q:
        return KNOWLEDGE_BASE["shap_explain"]
    elif "lime" in q:
        return KNOWLEDGE_BASE["lime_explain"]
    elif "model" in q or "random forest" in q or "xgboost" in q or "catboost" in q:
        return KNOWLEDGE_BASE["models"]
    elif "dissolved oxygen" in q or " do " in q or "oxygen" in q:
        return KNOWLEDGE_BASE["do_effect"]
    elif "n:p" in q or "ratio" in q or "nitrogen" in q or "phosphorus" in q:
        return KNOWLEDGE_BASE["np_ratio"]
    else:
        return (
            "I am the AquaSafe AI Research Assistant. I can answer questions about cyanobacterial blooms, water ecology, "
            "explain prediction results (SHAP/LIME), or explain the machine learning models. "
            "Please try asking: 'What causes blooms?', 'Suggest mitigation steps', 'How does SHAP work?', or 'What is the N:P ratio?'"
        )

@router.post("/", response_model=ChatResponse)
async def ask_assistant(request: ChatRequest, db: Session = Depends(get_db)):
    user_message = request.message
    
    # 1. Try Gemini API
    if settings.GEMINI_API_KEY:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={settings.GEMINI_API_KEY}"
        headers = {"Content-Type": "application/json"}
        prompt = (
            "You are an expert AI Water Quality & Cyanobacterial Bloom Research Assistant. "
            "Answer the user's question clearly and scientifically. "
            f"Context: {request.prediction_context or 'No specific lake prediction selected.'}\n"
            f"User Question: {user_message}"
        )
        payload = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(url, headers=headers, json=payload, timeout=12.0)
                if response.status_code == 200:
                    res_json = response.json()
                    answer = res_json["candidates"][0]["content"]["parts"][0]["text"]
                    return ChatResponse(response=answer, sources=["Google Gemini API"])
            except Exception:
                pass # Fallback to next provider

    # 2. Try OpenAI API
    if settings.OPENAI_API_KEY:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "gpt-4-turbo",
            "messages": [
                {"role": "system", "content": "You are a senior water quality and cyanobacteria research expert assisting environmental agencies."},
                {"role": "user", "content": f"Context: {request.prediction_context}\nQuestion: {user_message}"}
            ]
        }
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(url, headers=headers, json=payload, timeout=12.0)
                if response.status_code == 200:
                    res_json = response.json()
                    answer = res_json["choices"][0]["message"]["content"]
                    return ChatResponse(response=answer, sources=["OpenAI GPT-4 API"])
            except Exception:
                pass # Fallback to next

    # 3. Try Ollama Local LLM
    if settings.OLLAMA_HOST:
        url = f"{settings.OLLAMA_HOST}/api/generate"
        prompt = (
            f"System: You are an environmental AI assistant for AquaSafe AI.\n"
            f"Context: {request.prediction_context}\n"
            f"Question: {user_message}\n"
            "Response:"
        )
        payload = {
            "model": "llama3",
            "prompt": prompt,
            "stream": False
        }
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(url, json=payload, timeout=15.0)
                if response.status_code == 200:
                    res_json = response.json()
                    answer = res_json.get("response", "")
                    return ChatResponse(response=answer, sources=["Local Ollama (Llama 3)"])
            except Exception:
                pass

    # 4. Fallback: Search local offline knowledge engine
    answer = search_local_knowledge(user_message)
    return ChatResponse(response=answer, sources=["Local Eco-Intelligence Knowledge Base"])
