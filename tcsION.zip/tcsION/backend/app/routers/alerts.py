from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.database import Alert, AuditLog
from app.schemas.schemas import AlertResponse
from app.routers.auth import check_user_role, get_current_user

router = APIRouter(prefix="/alerts", tags=["Alert Center"])

@router.get("/", response_model=List[AlertResponse])
def get_alerts(
    is_resolved: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Alert)
    if is_resolved is not None:
        query = query.filter(Alert.is_resolved == is_resolved)
    return query.order_by(Alert.created_at.desc()).all()

@router.put("/{alert_id}/resolve")
def resolve_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin", "researcher"]))
):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
        
    alert.is_resolved = True
    
    # Audit log
    audit = AuditLog(user_id=current_user.id, action="ALERT_RESOLVE", details=f"Resolved alert {alert.id} for lake id {alert.lake_id}")
    db.add(audit)
    db.commit()
    
    return {"message": f"Alert {alert_id} marked as resolved"}
