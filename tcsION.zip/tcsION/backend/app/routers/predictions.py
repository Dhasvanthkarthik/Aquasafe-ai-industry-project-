import os
import joblib
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.database import Prediction, ModelRegistry, Lake, Alert, AuditLog
from app.schemas.schemas import PredictionCreate, PredictionResponse, SimulationInput, SimulationResponse
from app.routers.auth import check_user_role, get_current_user
from app.ml.engineering import calculate_derived_features
from app.ml.preprocessing import DataPreprocessor
from app.ml.explainability import ExplainabilityEngine
from app.services.weather import WeatherClient
import pandas as pd
import numpy as np

router = APIRouter(prefix="/predictions", tags=["Predictions Module"])

# Helper to run a heuristic prediction if no ML model is active
def run_heuristic_prediction(inputs: Dict[str, Any]) -> Tuple[str, str, float, Dict[str, float], Dict[str, Any]]:
    # Simple environmental risk formula
    temp = inputs.get("temperature", 20.0)
    ph = inputs.get("ph", 7.0)
    phosphorus = inputs.get("phosphorus", 0.05)
    do = inputs.get("dissolved_oxygen", 6.0)
    
    score = 0.0
    if temp > 25.0: score += 25
    if ph > 8.5: score += 15
    if phosphorus > 0.08: score += 35
    if do < 4.0: score += 25
    
    if score >= 60:
        severity = "High"
        risk = "High"
    elif score >= 30:
        severity = "Moderate"
        risk = "Moderate"
    else:
        severity = "Low"
        risk = "Low"
        
    confidence = 0.70 + (score / 400.0)
    probs = {
        "Low": max(0.0, 1.0 - (score/100.0)),
        "Moderate": min(score/100.0, 1.0 - abs(score-50)/100.0),
        "High": min(1.0, max(0.0, (score-30)/70.0))
    }
    # Normalize probabilities
    p_sum = sum(probs.values()) or 1.0
    probs = {k: round(v/p_sum, 2) for k, v in probs.items()}
    
    # Generate mock SHAP
    shap_contributions = [
        {"feature": "phosphorus", "value": phosphorus, "shap_value": 0.25 if phosphorus > 0.08 else 0.02},
        {"feature": "temperature", "value": temp, "shap_value": 0.18 if temp > 25 else -0.05},
        {"feature": "dissolved_oxygen", "value": do, "shap_value": -0.15 if do > 4.0 else 0.20},
        {"feature": "ph", "value": ph, "shap_value": 0.10 if ph > 8.0 else -0.02}
    ]
    shap_data = {
        "base_value": 0.35,
        "contributions": shap_contributions
    }
    
    return severity, risk, confidence, probs, shap_data


@router.post("/", response_model=PredictionResponse)
def create_prediction(
    pred_in: PredictionCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    lake = db.query(Lake).filter(Lake.id == pred_in.lake_id).first()
    if not lake:
        raise HTTPException(status_code=404, detail="Lake not found")

    # Construct input dict
    inputs = pred_in.dict()
    inputs.pop("lake_id")
    
    # Calculate derived features
    inputs_engineered = calculate_derived_features(inputs)

    # Try loading active model
    active_model_entry = db.query(ModelRegistry).filter(ModelRegistry.is_active == True).first()
    
    if active_model_entry and os.path.exists(active_model_entry.file_path):
        try:
            # Load ML model package
            package = joblib.load(active_model_entry.file_path)
            model = package["model"]
            metadata = package["metadata"]
            
            # Load preprocessor
            preprocessor = DataPreprocessor.load(metadata["preprocessor_path"])
            
            # Preprocess inputs
            input_df = pd.DataFrame([inputs_engineered])
            input_trans = preprocessor.transform(input_df)
            
            # Run prediction
            probs = model.predict_proba(input_trans)[0]
            classes = metadata["classes"]
            
            # Map probabilities
            probs_dict = {str(classes[i]): float(round(probs[i], 3)) for i in range(len(classes))}
            
            # Get predicted class
            predicted_idx = np.argmax(probs)
            bloom_severity = str(classes[predicted_idx])
            health_risk = bloom_severity # In our mapping severity matches risk, but can be derived
            
            confidence_score = float(probs[predicted_idx])
            
            # Compute SHAP
            shap_data = ExplainabilityEngine.compute_shap_values(model, input_trans)
            
        except Exception as e:
            # Fallback to Heuristic if ML fails
            bloom_severity, health_risk, confidence_score, probs_dict, shap_data = run_heuristic_prediction(inputs_engineered)
    else:
        # Fallback Heuristic
        bloom_severity, health_risk, confidence_score, probs_dict, shap_data = run_heuristic_prediction(inputs_engineered)

    # Generate recommendations
    rec = ExplainabilityEngine.generate_natural_language_explanation(inputs_engineered, bloom_severity, health_risk)
    
    # Generate action plan based on risk level
    if health_risk == "High":
        rec += " RECOMMENDATION: Issue immediate public contact ban. Dispatch field sampling crew. Activate aerators or copper sulfate treatment procedures."
    elif health_risk == "Moderate":
        rec += " RECOMMENDATION: Increase sampling frequency to semi-weekly. Post cautionary signage. Inform water treatment plant to monitor taste/odor compound entry."
    else:
        rec += " RECOMMENDATION: Continue standard monitoring schedule. No recreational restrictions."

    # Create Alert if High Risk
    trigger_alert = (health_risk == "High")
    
    db_pred = Prediction(
        lake_id=lake.id,
        temperature=pred_in.temperature,
        ph=pred_in.ph,
        rainfall=pred_in.rainfall,
        humidity=pred_in.humidity,
        wind_speed=pred_in.wind_speed,
        sunlight=pred_in.sunlight,
        dissolved_oxygen=pred_in.dissolved_oxygen,
        conductivity=pred_in.conductivity,
        bod=pred_in.bod,
        nitrogen=pred_in.nitrogen,
        phosphorus=pred_in.phosphorus,
        season=pred_in.season,
        bloom_severity=bloom_severity,
        health_risk=health_risk,
        confidence_score=confidence_score,
        probabilities_json=probs_dict,
        shap_explanation_json=shap_data,
        recommendations=rec,
        is_alert_triggered=trigger_alert
    )
    
    db.add(db_pred)
    db.commit()
    db.refresh(db_pred)

    if trigger_alert:
        alert = Alert(
            lake_id=lake.id,
            prediction_id=db_pred.id,
            severity="High",
            message=f"WARNING: Cyanobacterial bloom health risk at {lake.name} is HIGH. Severity index predicted at {confidence_score*100:.1f}%. Action required."
        )
        db.add(alert)
        db.commit()
        
    return db_pred

@router.post("/simulation", response_model=SimulationResponse)
def simulate_prediction(
    sim_in: SimulationInput,
    db: Session = Depends(get_db)
):
    base_pred = db.query(Prediction).filter(Prediction.id == sim_in.base_prediction_id).first()
    if not base_pred:
        raise HTTPException(status_code=404, detail="Base prediction log not found")
        
    # Construct base dict
    base_inputs = {
        "temperature": base_pred.temperature,
        "ph": base_pred.ph,
        "rainfall": base_pred.rainfall,
        "humidity": base_pred.humidity,
        "wind_speed": base_pred.wind_speed,
        "sunlight": base_pred.sunlight,
        "dissolved_oxygen": base_pred.dissolved_oxygen,
        "conductivity": base_pred.conductivity,
        "bod": base_pred.bod,
        "nitrogen": base_pred.nitrogen,
        "phosphorus": base_pred.phosphorus,
        "season": base_pred.season
    }
    
    # Apply modifications
    mod_inputs = base_inputs.copy()
    for k, v in sim_in.modifications.items():
        if k in mod_inputs:
            mod_inputs[k] = v

    # Predict before
    before_severity, before_risk, before_conf, before_probs, _ = run_heuristic_prediction(base_inputs)
    # Predict after
    after_severity, after_risk, after_conf, after_probs, _ = run_heuristic_prediction(mod_inputs)
    
    # Calculate improvement percentage: reduction in High probability
    p_high_before = before_probs.get("High", 0.0)
    p_high_after = after_probs.get("High", 0.0)
    
    if p_high_before > 0:
        improvement = ((p_high_before - p_high_after) / p_high_before) * 100.0
    else:
        improvement = 0.0

    return {
        "before": {
            "bloom_severity": before_severity,
            "health_risk": before_risk,
            "confidence": before_conf,
            "probabilities": before_probs
        },
        "after": {
            "bloom_severity": after_severity,
            "health_risk": after_risk,
            "confidence": after_conf,
            "probabilities": after_probs
        },
        "improvement_percentage": round(improvement, 2)
    }

@router.get("/history", response_model=List[PredictionResponse])
def get_prediction_history(
    lake_id: Optional[int] = None,
    severity: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Prediction)
    if lake_id:
        query = query.filter(Prediction.lake_id == lake_id)
    if severity:
        query = query.filter(Prediction.bloom_severity == severity)
        
    return query.order_by(Prediction.timestamp.desc()).all()

@router.get("/forecast/{lake_id}")
async def get_lake_forecast(
    lake_id: int,
    db: Session = Depends(get_db)
):
    lake = db.query(Lake).filter(Lake.id == lake_id).first()
    if not lake:
        raise HTTPException(status_code=404, detail="Lake not found")
        
    # Get weather forecast using Open-Meteo API
    try:
        weather_data = await WeatherClient.get_forecast(lake.latitude, lake.longitude)
    except Exception:
        # Fallback weather forecast if API fails
        weather_data = []
        for i in range(7):
            date = datetime.now() + timedelta(days=i)
            weather_data.append({
                "date": date.strftime("%Y-%m-%d"),
                "temperature": 22.0 + np.sin(i/2) * 5,
                "humidity": 65.0,
                "rainfall": 2.0 if i == 3 else 0.0,
                "wind_speed": 12.0
            })

    forecast_results = []
    
    # Average base parameters from historical readings of this lake
    avg_ph = 7.5
    avg_do = 6.5
    avg_phosphorus = 0.04
    avg_nitrogen = 0.6
    avg_bod = 2.0
    avg_conductivity = 250.0

    # Fetch latest prediction inputs as a baseline
    latest_pred = db.query(Prediction).filter(Prediction.lake_id == lake_id).order_by(Prediction.timestamp.desc()).first()
    if latest_pred:
        avg_ph = latest_pred.ph
        avg_do = latest_pred.dissolved_oxygen
        avg_phosphorus = latest_pred.phosphorus
        avg_nitrogen = latest_pred.nitrogen
        avg_bod = latest_pred.bod
        avg_conductivity = latest_pred.conductivity

    for i, w in enumerate(weather_data):
        inputs = {
            "temperature": w["temperature"],
            "ph": avg_ph,
            "rainfall": w["rainfall"],
            "humidity": w["humidity"],
            "wind_speed": w["wind_speed"],
            "sunlight": 10.0, # default index
            "dissolved_oxygen": avg_do,
            "conductivity": avg_conductivity,
            "bod": avg_bod,
            "nitrogen": avg_nitrogen,
            "phosphorus": avg_phosphorus,
            "season": "Summer" if datetime.now().month in [6, 7, 8] else "Spring"
        }
        
        severity, risk, confidence, probs, _ = run_heuristic_prediction(inputs)
        forecast_results.append({
            "day": w["date"],
            "temperature": w["temperature"],
            "rainfall": w["rainfall"],
            "bloom_severity": severity,
            "health_risk": risk,
            "probabilities": probs
        })

    return forecast_results
