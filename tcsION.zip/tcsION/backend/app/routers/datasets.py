import os
import shutil
import pandas as pd
import json
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.database import Dataset, AuditLog
from app.schemas.schemas import DatasetResponse
from app.routers.auth import check_user_role
from app.ml.preprocessing import DataPreprocessor

router = APIRouter(prefix="/datasets", tags=["Dataset Management"])

UPLOAD_DIR = "./uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Helper to map uploaded columns to standard names
COLUMN_MAPPINGS = {
    "temp": "temperature", "temperature": "temperature", "temp_c": "temperature",
    "ph": "ph", "ph_level": "ph",
    "rain": "rainfall", "rainfall": "rainfall", "precipitation": "rainfall",
    "humidity": "humidity", "rel_humidity": "humidity",
    "wind": "wind_speed", "windspeed": "wind_speed", "wind_speed": "wind_speed",
    "sun": "sunlight", "sunlight": "sunlight", "uv": "sunlight",
    "do": "dissolved_oxygen", "dissolved_oxygen": "dissolved_oxygen", "oxygen": "dissolved_oxygen",
    "cond": "conductivity", "conductivity": "conductivity",
    "bod": "bod", "oxygen_demand": "bod",
    "nitrogen": "nitrogen", "n": "nitrogen", "nitrate": "nitrogen",
    "phosphorus": "phosphorus", "p": "phosphorus", "phosphate": "phosphorus",
    "season": "season",
    "severity": "bloom_severity", "bloom_severity": "bloom_severity", "risk": "health_risk"
}

def clean_and_map_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Standardizes column names based on common variants."""
    new_cols = {}
    for col in df.columns:
        clean_col = col.strip().lower().replace(" ", "_")
        if clean_col in COLUMN_MAPPINGS:
            new_cols[col] = COLUMN_MAPPINGS[clean_col]
        else:
            new_cols[col] = clean_col
    return df.rename(columns=new_cols)

@router.get("/", response_model=List[DatasetResponse])
def get_datasets(db: Session = Depends(get_db)):
    return db.query(Dataset).all()

@router.post("/upload", response_model=DatasetResponse)
def upload_dataset(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin", "researcher"]))
):
    # Check file extension
    file_ext = os.path.splitext(file.filename)[1].lower()
    if file_ext not in [".csv", ".xlsx", ".xls"]:
        raise HTTPException(
            status_code=400,
            detail="Invalid file format. Only CSV and Excel (.xlsx, .xls) are supported."
        )

    # Save file
    file_path = os.path.join(UPLOAD_DIR, f"{current_user.id}_{file.filename}")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        # Load file into DataFrame
        if file_ext == ".csv":
            df = pd.read_csv(file_path)
        else:
            df = pd.read_excel(file_path)

        if df.empty:
            os.remove(file_path)
            raise HTTPException(status_code=400, detail="Uploaded file is empty")

        # Map headers
        df_mapped = clean_and_map_columns(df)

        # Run Preprocessing for Statistics & Quality Check
        preprocessor = DataPreprocessor()
        quality_report = preprocessor.get_data_quality_report(df_mapped)

        # Calculate correlations for numeric features
        numeric_df = df_mapped.select_dtypes(include=["number"])
        correlations = {}
        if not numeric_df.empty:
            corr_matrix = numeric_df.corr().round(3).fillna(0.0)
            correlations = corr_matrix.to_dict()

        # Class balance (target distribution if it exists)
        class_balance = {}
        target_col = "bloom_severity"
        if target_col in df_mapped.columns:
            balance = df_mapped[target_col].value_counts().to_dict()
            class_balance = {str(k): int(v) for k, v in balance.items()}

        stats_payload = {
            "columns": df_mapped.columns.tolist(),
            "data_quality_report": quality_report,
            "correlations": correlations,
            "class_balance": class_balance,
            "missing_per_col": df_mapped.isnull().sum().to_dict()
        }

        db_dataset = Dataset(
            name=file.filename,
            filename=file_path,
            row_count=len(df_mapped),
            col_count=len(df_mapped.columns),
            data_quality_score=quality_report["data_quality_score"],
            duplicate_count=quality_report["duplicate_count"],
            missing_count=quality_report["missing_count"],
            outlier_count=quality_report["outlier_count"],
            stats_json=stats_payload
        )

        db.add(db_dataset)
        db.commit()
        db.refresh(db_dataset)

        audit = AuditLog(
            user_id=current_user.id, 
            action="DATASET_UPLOAD", 
            details=f"Uploaded dataset {file.filename} ({len(df_mapped)} rows)"
        )
        db.add(audit)
        db.commit()

        return db_dataset

    except Exception as e:
        if os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while parsing the dataset: {str(e)}"
        )

@router.get("/{dataset_id}/preview")
def get_dataset_preview(
    dataset_id: int, 
    rows: int = 10,
    db: Session = Depends(get_db)
):
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")
        
    if not os.path.exists(dataset.filename):
        raise HTTPException(status_code=404, detail="Physical dataset file missing on server")

    try:
        file_ext = os.path.splitext(dataset.filename)[1].lower()
        if file_ext == ".csv":
            df = pd.read_csv(dataset.filename, nrows=rows)
        else:
            df = pd.read_excel(dataset.filename, nrows=rows)
            
        df_mapped = clean_and_map_columns(df)
        # Convert NaN to None for JSON serialization
        df_mapped = df_mapped.replace({np.nan: None})
        return {
            "headers": df_mapped.columns.tolist(),
            "data": df_mapped.to_dict(orient="records")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read dataset: {str(e)}")

@router.delete("/{dataset_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_dataset(
    dataset_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(check_user_role(["admin", "researcher"]))
):
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # Delete physical file
    if os.path.exists(dataset.filename):
        try:
            os.remove(dataset.filename)
        except Exception:
            pass

    db.delete(dataset)
    db.commit()
    return None
