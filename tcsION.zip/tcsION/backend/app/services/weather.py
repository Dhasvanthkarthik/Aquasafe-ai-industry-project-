import httpx
from typing import Dict, Any, List
from app.core.config import settings

class WeatherClient:
    @staticmethod
    async def get_forecast(latitude: float, longitude: float) -> List[Dict[str, Any]]:
        """
        Fetches a 7-day daily weather forecast from the Open-Meteo API.
        Returns a list of structured daily parameters.
        """
        url = f"{settings.OPEN_METEO_URL}?latitude={latitude}&longitude={longitude}&daily=temperature_2m_max,relative_humidity_2m_mean,precipitation_sum,wind_speed_10m_max&timezone=auto"
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, timeout=10.0)
                if response.status_code == 200:
                    data = response.json()
                    daily = data.get("daily", {})
                    
                    forecast = []
                    times = daily.get("time", [])
                    temps = daily.get("temperature_2m_max", [])
                    humidities = daily.get("relative_humidity_2m_mean", [])
                    rains = daily.get("precipitation_sum", [])
                    winds = daily.get("wind_speed_10m_max", [])
                    
                    for idx in range(len(times)):
                        forecast.append({
                            "date": times[idx],
                            "temperature": float(temps[idx]) if temps[idx] is not None else 20.0,
                            "humidity": float(humidities[idx]) if humidities[idx] is not None else 65.0,
                            "rainfall": float(rains[idx]) if rains[idx] is not None else 0.0,
                            "wind_speed": float(winds[idx]) if winds[idx] is not None else 10.0
                        })
                    return forecast
                else:
                    raise Exception(f"Open-Meteo returned status {response.status_code}")
            except Exception as e:
                # Log error and raise so parent can trigger fallback parameters
                raise RuntimeError(f"Failed to retrieve weather data from Open-Meteo: {str(e)}")

    @staticmethod
    async def get_current_weather(latitude: float, longitude: float) -> Dict[str, Any]:
        """
        Fetches current weather parameters for a lake.
        """
        url = f"{settings.OPEN_METEO_URL}?latitude={latitude}&longitude={longitude}&current_weather=true"
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, timeout=10.0)
                if response.status_code == 200:
                    data = response.json()
                    current = data.get("current_weather", {})
                    return {
                        "temperature": current.get("temperature", 20.0),
                        "wind_speed": current.get("windspeed", 10.0),
                        "humidity": 60.0, # Default since current_weather does not return humidity
                        "rainfall": 0.0,
                        "sunlight": 8.0
                    }
                else:
                    return {"temperature": 20.0, "wind_speed": 10.0, "humidity": 60.0, "rainfall": 0.0, "sunlight": 8.0}
            except Exception:
                return {"temperature": 20.0, "wind_speed": 10.0, "humidity": 60.0, "rainfall": 0.0, "sunlight": 8.0}
