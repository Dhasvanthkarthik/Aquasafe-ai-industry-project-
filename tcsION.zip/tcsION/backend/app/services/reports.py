import os
from io import BytesIO
import pandas as pd
from datetime import datetime
from typing import List, Dict
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

class ReportGenerator:
    @staticmethod
    def generate_prediction_pdf(prediction_data: dict, lake_name: str) -> BytesIO:
        """
        Generates a formatted PDF report for a single prediction run.
        """
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
        )
        
        styles = getSampleStyleSheet()
        
        # Custom styles for dark theme/primary styling
        primary_color = colors.HexColor("#0D9488") # Teal 600
        secondary_color = colors.HexColor("#0F172A") # Slate 900
        warning_color = colors.HexColor("#DC2626") # Red 600
        
        title_style = ParagraphStyle(
            'ReportTitle',
            parent=styles['Heading1'],
            fontSize=22,
            textColor=primary_color,
            spaceAfter=15
        )
        
        section_heading = ParagraphStyle(
            'SectionHeading',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=secondary_color,
            spaceAfter=10,
            spaceBefore=15
        )
        
        body_style = ParagraphStyle(
            'BodyTextCustom',
            parent=styles['BodyText'],
            fontSize=10,
            leading=14,
            spaceAfter=8
        )

        bold_style = ParagraphStyle(
            'BoldTextCustom',
            parent=body_style,
            fontName='Helvetica-Bold'
        )

        story = []
        
        # Header
        story.append(Paragraph("AquaSafe AI – Environmental Intelligence Report", title_style))
        story.append(Paragraph(f"<b>Lake Name:</b> {lake_name} | <b>Date:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", body_style))
        story.append(Spacer(1, 10))
        
        # Risk Summary Card
        risk_level = prediction_data.get("health_risk", "Low")
        risk_color = warning_color if risk_level == "High" else (colors.HexColor("#CA8A04") if risk_level == "Moderate" else colors.HexColor("#16A34A"))
        
        summary_text = (
            f"<b>Bloom Severity:</b> {prediction_data.get('bloom_severity')}<br/>"
            f"<b>Public Health Risk:</b> <font color='{risk_color}'><b>{risk_level}</b></font><br/>"
            f"<b>Prediction Confidence:</b> {prediction_data.get('confidence_score')*100:.1f}%"
        )
        
        summary_table_data = [[Paragraph(summary_text, bold_style)]]
        summary_table = Table(summary_table_data, colWidths=[500])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
            ('PADDING', (0,0), (-1,-1), 12),
            ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#E2E8F0")),
            ('LINELEFT', (0,0), (-1,-1), 4, risk_color)
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 15))
        
        # Environmental Parameters
        story.append(Paragraph("Monitored Environmental Parameters", section_heading))
        
        param_data = [
            [Paragraph("<b>Parameter</b>", bold_style), Paragraph("<b>Value</b>", bold_style), Paragraph("<b>Parameter</b>", bold_style), Paragraph("<b>Value</b>", bold_style)],
            ["Temperature", f"{prediction_data.get('temperature')} °C", "pH Level", f"{prediction_data.get('ph')}"],
            ["Dissolved Oxygen", f"{prediction_data.get('dissolved_oxygen')} mg/L", "Conductivity", f"{prediction_data.get('conductivity')} uS/cm"],
            ["Rainfall", f"{prediction_data.get('rainfall')} mm", "Humidity", f"{prediction_data.get('humidity')} %"],
            ["Wind Speed", f"{prediction_data.get('wind_speed')} km/h", "Sunlight Index", f"{prediction_data.get('sunlight')}"],
            ["Nitrogen", f"{prediction_data.get('nitrogen')} mg/L", "Phosphorus", f"{prediction_data.get('phosphorus')} mg/L"],
            ["BOD", f"{prediction_data.get('bod')} mg/L", "Season", f"{prediction_data.get('season')}"]
        ]
        
        t = Table(param_data, colWidths=[150, 100, 150, 100])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#E2E8F0")),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
            ('PADDING', (0,0), (-1,-1), 6),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold')
        ]))
        story.append(t)
        story.append(Spacer(1, 15))
        
        # Recommendations
        story.append(Paragraph("AI-Generated Recommendations & Explanations", section_heading))
        story.append(Paragraph(prediction_data.get("recommendations", "No specific recommendations generated."), body_style))
        story.append(Spacer(1, 15))
        
        # SHAP Explainability table
        story.append(Paragraph("Top Environmental Contributors (SHAP Analysis)", section_heading))
        
        shap_json = prediction_data.get("shap_explanation_json", {})
        contributions = shap_json.get("contributions", []) if isinstance(shap_json, dict) else []
        
        if contributions:
            shap_table_data = [[
                Paragraph("<b>Feature</b>", bold_style),
                Paragraph("<b>Observed Value</b>", bold_style),
                Paragraph("<b>SHAP Impact</b>", bold_style)
            ]]
            
            # Show top 5 contributors
            for item in contributions[:6]:
                impact = item.get("shap_value", 0.0)
                impact_text = f"+{impact:.3f} (Raises Risk)" if impact >= 0 else f"{impact:.3f} (Suppresses Risk)"
                impact_color = "red" if impact >= 0 else "green"
                
                shap_table_data.append([
                    item.get("feature").replace("_", " ").title(),
                    str(item.get("value")),
                    Paragraph(f"<font color='{impact_color}'><b>{impact_text}</b></font>", body_style)
                ])
                
            st = Table(shap_table_data, colWidths=[200, 150, 150])
            st.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#E2E8F0")),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
                ('PADDING', (0,0), (-1,-1), 6)
            ]))
            story.append(st)
        else:
            story.append(Paragraph("SHAP explainability values not computed for this prediction.", body_style))

        # Build PDF
        doc.build(story)
        buffer.seek(0)
        return buffer

    @staticmethod
    def generate_excel_export(predictions: List[dict], lake_names_map: Dict[int, str]) -> BytesIO:
        """
        Exports multiple predictions into a clean Excel spreadsheet.
        """
        buffer = BytesIO()
        
        rows = []
        for p in predictions:
            rows.append({
                "Prediction ID": p.id,
                "Lake": lake_names_map.get(p.lake_id, f"Lake {p.lake_id}"),
                "Timestamp": p.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "Temperature (°C)": p.temperature,
                "pH": p.ph,
                "DO (mg/L)": p.dissolved_oxygen,
                "Rainfall (mm)": p.rainfall,
                "Humidity (%)": p.humidity,
                "Wind Speed (km/h)": p.wind_speed,
                "Sunlight Index": p.sunlight,
                "Nitrogen (mg/L)": p.nitrogen,
                "Phosphorus (mg/L)": p.phosphorus,
                "BOD (mg/L)": p.bod,
                "Conductivity (uS/cm)": p.conductivity,
                "Season": p.season,
                "Bloom Severity": p.bloom_severity,
                "Health Risk": p.health_risk,
                "Confidence": p.confidence_score
            })
            
        df = pd.DataFrame(rows)
        with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
            df.to_sheet = df.to_excel(writer, index=False, sheet_name="Prediction Logs")
            
        buffer.seek(0)
        return buffer
