from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="guest")  # admin, researcher, analyst, guest
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    notes = relationship("ResearchNote", back_populates="user", cascade="all, delete-orphan")
    audit_logs = relationship("AuditLog", back_populates="user", cascade="all, delete-orphan")

class Lake(Base):
    __tablename__ = "lakes"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    location_code = Column(String, unique=True, nullable=False)
    active_status = Column(String, default="Active")  # Active, Inactive, Maintenance
    created_at = Column(DateTime, default=datetime.utcnow)

    predictions = relationship("Prediction", back_populates="lake", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="lake", cascade="all, delete-orphan")
    weather_history = relationship("WeatherHistory", back_populates="lake", cascade="all, delete-orphan")

class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    lake_id = Column(Integer, ForeignKey("lakes.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Input parameters
    temperature = Column(Float, nullable=False)
    ph = Column(Float, nullable=False)
    rainfall = Column(Float, nullable=False)
    humidity = Column(Float, nullable=False)
    wind_speed = Column(Float, nullable=False)
    sunlight = Column(Float, nullable=False)
    dissolved_oxygen = Column(Float, nullable=False)
    conductivity = Column(Float, nullable=False)
    bod = Column(Float, nullable=False)
    nitrogen = Column(Float, nullable=False)
    phosphorus = Column(Float, nullable=False)
    season = Column(String, nullable=False)
    
    # Outputs
    bloom_severity = Column(String, nullable=False)  # Low, Moderate, High
    health_risk = Column(String, nullable=False)     # Low, Moderate, High
    confidence_score = Column(Float, nullable=False)
    probabilities_json = Column(JSON, nullable=True) # { "Low": 0.1, "Moderate": 0.2, "High": 0.7 }
    shap_explanation_json = Column(JSON, nullable=True)
    recommendations = Column(Text, nullable=True)
    is_alert_triggered = Column(Boolean, default=False)

    lake = relationship("Lake", back_populates="predictions")
    alerts = relationship("Alert", back_populates="prediction", cascade="all, delete-orphan")

class Dataset(Base):
    __tablename__ = "datasets"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    filename = Column(String, nullable=False)
    row_count = Column(Integer, nullable=False)
    col_count = Column(Integer, nullable=False)
    data_quality_score = Column(Float, default=100.0)
    duplicate_count = Column(Integer, default=0)
    missing_count = Column(Integer, default=0)
    outlier_count = Column(Integer, default=0)
    stats_json = Column(JSON, nullable=True)
    upload_timestamp = Column(DateTime, default=datetime.utcnow)

class ModelRegistry(Base):
    __tablename__ = "model_registry"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    version = Column(Integer, nullable=False)
    model_type = Column(String, nullable=False)  # RandomForest, SVM, MLP, GradientBoosting, XGBoost, CatBoost, LightGBM
    accuracy = Column(Float, nullable=False)
    f1_score = Column(Float, nullable=False)
    precision_score = Column(Float, nullable=False)
    recall_score = Column(Float, nullable=False)
    auc_score = Column(Float, nullable=False)
    is_active = Column(Boolean, default=False)
    parameters_json = Column(JSON, nullable=True)
    metrics_history_json = Column(JSON, nullable=True)
    file_path = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    lake_id = Column(Integer, ForeignKey("lakes.id"), nullable=False)
    prediction_id = Column(Integer, ForeignKey("predictions.id"), nullable=False)
    severity = Column(String, nullable=False) # High, Moderate, Low
    message = Column(Text, nullable=False)
    is_resolved = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    lake = relationship("Lake", back_populates="alerts")
    prediction = relationship("Prediction", back_populates="alerts")

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String, nullable=False)
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="audit_logs")

class ResearchNote(Base):
    __tablename__ = "research_notes"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notes")

class WeatherHistory(Base):
    __tablename__ = "weather_history"

    id = Column(Integer, primary_key=True, index=True)
    lake_id = Column(Integer, ForeignKey("lakes.id"), nullable=False)
    date = Column(DateTime, nullable=False)
    temperature = Column(Float, nullable=False)
    humidity = Column(Float, nullable=False)
    rainfall = Column(Float, nullable=False)
    wind_speed = Column(Float, nullable=False)

    lake = relationship("Lake", back_populates="weather_history")
