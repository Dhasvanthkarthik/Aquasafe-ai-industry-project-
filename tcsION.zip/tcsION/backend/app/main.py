from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.core.config import settings
from app.database import engine, get_db, Base
from app.models.database import Prediction, Lake
from app.services.reports import ReportGenerator

# Routers
from app.routers import auth, lakes, datasets, models_api, predictions, alerts, chatbot

# Create tables on startup (especially helpful for sqlite)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Intelligent Cyanobacterial Bloom & Public Health Risk Prediction System Backend",
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# CORS configuration
origins = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "*" # Fallback for easy docker routing
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(lakes.router, prefix=settings.API_V1_STR)
app.include_router(datasets.router, prefix=settings.API_V1_STR)
app.include_router(models_api.router, prefix=settings.API_V1_STR)
app.include_router(predictions.router, prefix=settings.API_V1_STR)
app.include_router(alerts.router, prefix=settings.API_V1_STR)
app.include_router(chatbot.router, prefix=settings.API_V1_STR)

@app.get("/")
def read_root():
    return {
        "status": "Online",
        "system": settings.PROJECT_NAME,
        "api_docs": "/docs"
    }

# Dedicated Report Export Endpoints
@app.get(f"{settings.API_V1_STR}/reports/prediction/pdf/{{prediction_id}}")
def export_prediction_pdf(prediction_id: int, db: Session = Depends(get_db)):
    pred = db.query(Prediction).filter(Prediction.id == prediction_id).first()
    if not pred:
        raise HTTPException(status_code=404, detail="Prediction log not found")
        
    lake = db.query(Lake).filter(Lake.id == pred.lake_id).first()
    lake_name = lake.name if lake else f"Lake ID {pred.lake_id}"
    
    # Serialize prediction mapping
    pred_data = {
        "temperature": pred.temperature,
        "ph": pred.ph,
        "dissolved_oxygen": pred.dissolved_oxygen,
        "conductivity": pred.conductivity,
        "rainfall": pred.rainfall,
        "humidity": pred.humidity,
        "wind_speed": pred.wind_speed,
        "sunlight": pred.sunlight,
        "nitrogen": pred.nitrogen,
        "phosphorus": pred.phosphorus,
        "bod": pred.bod,
        "season": pred.season,
        "bloom_severity": pred.bloom_severity,
        "health_risk": pred.health_risk,
        "confidence_score": pred.confidence_score,
        "recommendations": pred.recommendations,
        "shap_explanation_json": pred.shap_explanation_json
    }
    
    pdf_buffer = ReportGenerator.generate_prediction_pdf(pred_data, lake_name)
    
    return StreamingResponse(
        pdf_buffer,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=aquasafe_report_{prediction_id}.pdf"}
    )

@app.get(f"{settings.API_V1_STR}/reports/predictions/excel")
def export_predictions_excel(db: Session = Depends(get_db)):
    predictions = db.query(Prediction).all()
    if not predictions:
        raise HTTPException(status_code=404, detail="No predictions to export")
        
    lakes = db.query(Lake).all()
    lakes_map = {l.id: l.name for l in lakes}
    
    # Convert predictions to dicts
    pred_list = []
    for p in predictions:
        pred_list.append(p)
        
    excel_buffer = ReportGenerator.generate_excel_export(pred_list, lakes_map)
    
    return StreamingResponse(
        excel_buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=aquasafe_predictions_history.xlsx"}
    )
