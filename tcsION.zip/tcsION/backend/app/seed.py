import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from app.database import SessionLocal, Base, engine
from app.core import security
from app.models.database import User, Lake, Prediction, Alert, Dataset

def generate_sample_csv(filename: str):
    """Generates a high-quality synthetic dataset for cyanobacteria bloom model training."""
    np.random.seed(42)
    n_samples = 200
    
    # Generate realistic correlated parameters
    temp = np.random.uniform(15.0, 35.0, n_samples)
    ph = np.random.uniform(6.5, 9.5, n_samples)
    phosphorus = np.random.uniform(0.01, 0.25, n_samples)
    nitrogen = np.random.uniform(0.1, 2.5, n_samples)
    
    # Dissolved oxygen goes down when temperature is high, and spikes then drops during blooms
    do = 12.0 - (temp * 0.2) + np.random.normal(0, 0.8, n_samples)
    do = np.clip(do, 1.5, 14.0)
    
    rainfall = np.random.exponential(scale=5.0, size=n_samples)
    humidity = np.random.uniform(40.0, 95.0, n_samples)
    wind_speed = np.random.uniform(2.0, 25.0, n_samples)
    sunlight = np.random.uniform(2.0, 12.0, n_samples)
    bod = (phosphorus * 25.0) + (temp * 0.1) + np.random.normal(0, 0.5, n_samples)
    bod = np.clip(bod, 0.5, 10.0)
    conductivity = 150.0 + (ph * 20.0) + np.random.normal(0, 15, n_samples)
    
    seasons = np.random.choice(["Spring", "Summer", "Autumn", "Winter"], n_samples)
    
    # Calculate Severity Label heuristically
    severity_labels = []
    for i in range(n_samples):
        score = 0.0
        if temp[i] > 26.0: score += 3.0
        if ph[i] > 8.5: score += 2.0
        if phosphorus[i] > 0.09: score += 5.0
        if nitrogen[i] > 1.2: score += 3.0
        if do[i] < 4.5: score += 4.0
        if rainfall[i] > 15.0: score += 1.5 # nutrient runoff
        
        if score >= 10.0:
            severity_labels.append("High")
        elif score >= 5.0:
            severity_labels.append("Moderate")
        else:
            severity_labels.append("Low")

    df = pd.DataFrame({
        "temperature": np.round(temp, 1),
        "ph": np.round(ph, 2),
        "rainfall": np.round(rainfall, 1),
        "humidity": np.round(humidity, 1),
        "wind_speed": np.round(wind_speed, 1),
        "sunlight": np.round(sunlight, 1),
        "dissolved_oxygen": np.round(do, 2),
        "conductivity": np.round(conductivity, 1),
        "bod": np.round(bod, 2),
        "nitrogen": np.round(nitrogen, 2),
        "phosphorus": np.round(phosphorus, 3),
        "season": seasons,
        "bloom_severity": severity_labels
    })
    
    df.to_csv(filename, index=False)
    print(f"Sample dataset saved to {filename}")

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    # 1. Create Users
    if db.query(User).count() == 0:
        users = [
            User(username="admin", email="admin@aquasafe.ai", hashed_password=security.get_password_hash("admin123"), role="admin"),
            User(username="researcher", email="researcher@aquasafe.ai", hashed_password=security.get_password_hash("researcher123"), role="researcher"),
            User(username="analyst", email="analyst@aquasafe.ai", hashed_password=security.get_password_hash("analyst123"), role="analyst")
        ]
        db.add_all(users)
        db.commit()
        print("Users seeded successfully.")

    # 2. Create Lakes
    if db.query(Lake).count() == 0:
        lakes = [
            Lake(name="Lake Eutrophic", latitude=42.3601, longitude=-71.0589, location_code="LE_01", active_status="Active"),
            Lake(name="Lake Oligotrophic", latitude=43.6532, longitude=-79.3832, location_code="LO_02", active_status="Active"),
            Lake(name="Lake Mesotrophic", latitude=34.0522, longitude=-118.2437, location_code="LM_03", active_status="Active"),
            Lake(name="Lake Algae", latitude=37.7749, longitude=-122.4194, location_code="LA_04", active_status="Maintenance")
        ]
        db.add_all(lakes)
        db.commit()
        print("Lakes seeded successfully.")

    # 3. Create Sample Predictions & Alert logs
    if db.query(Prediction).count() == 0:
        lakes_db = db.query(Lake).all()
        
        # Populate history for the past 15 days
        for lake in lakes_db:
            base_temp = 28.0 if "Eutrophic" in lake.name or "Algae" in lake.name else 18.0
            base_p = 0.15 if "Eutrophic" in lake.name or "Algae" in lake.name else 0.02
            base_do = 3.5 if "Eutrophic" in lake.name or "Algae" in lake.name else 8.0
            
            for day_offset in range(15):
                date = datetime.utcnow() - timedelta(days=day_offset)
                temp = base_temp + np.sin(day_offset) * 2.0
                ph = 8.8 + np.cos(day_offset) * 0.3 if base_temp > 20 else 7.2
                p = base_p + np.random.uniform(-0.01, 0.02)
                do = base_do + np.random.uniform(-0.5, 0.5)
                
                # Derive Risk Level
                severity = "High" if p > 0.08 and temp > 24 else ("Moderate" if temp > 20 else "Low")
                risk = severity
                conf = 0.82 if severity == "High" else 0.89
                
                probs = {"Low": 0.05, "Moderate": 0.15, "High": 0.80} if severity == "High" else (
                    {"Low": 0.15, "Moderate": 0.70, "High": 0.15} if severity == "Moderate" else
                    {"Low": 0.90, "Moderate": 0.08, "High": 0.02}
                )
                
                pred = Prediction(
                    lake_id=lake.id,
                    timestamp=date,
                    temperature=temp,
                    ph=ph,
                    rainfall=2.5,
                    humidity=65.0,
                    wind_speed=12.0,
                    sunlight=9.0,
                    dissolved_oxygen=do,
                    conductivity=230.0,
                    bod=4.5 if base_temp > 20 else 1.2,
                    nitrogen=1.1,
                    phosphorus=p,
                    season="Summer",
                    bloom_severity=severity,
                    health_risk=risk,
                    confidence_score=conf,
                    probabilities_json=probs,
                    recommendations="Seeded prediction record for testing and visual charts.",
                    is_alert_triggered=(severity == "High")
                )
                db.add(pred)
                db.commit()
                db.refresh(pred)
                
                if severity == "High" and day_offset == 0:
                    alert = Alert(
                        lake_id=lake.id,
                        prediction_id=pred.id,
                        severity="High",
                        message=f"WARNING: High bloom risk detected at {lake.name}."
                    )
                    db.add(alert)
                    db.commit()
                    
        print("Historical prediction logs seeded.")
    
    db.close()

if __name__ == "__main__":
    generate_sample_csv("sample_bloom_data.csv")
    seed_database()
