import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base, get_db
from app.main import app

# Set up clean in-memory SQLite database for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

@pytest.fixture(scope="module", autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "Online"

def test_auth_workflow():
    # 0. Create initial user (will auto-promote to admin)
    admin_payload = {
        "username": "adminuser",
        "email": "adminuser@gmail.com",
        "password": "adminpassword123",
        "role": "admin"
    }
    admin_response = client.post("/api/v1/auth/signup", json=admin_payload)
    assert admin_response.status_code == 200
    assert admin_response.json()["role"] == "admin"

    # 1. Signup standard analyst user
    signup_payload = {
        "username": "testuser",
        "email": "testuser@gmail.com",
        "password": "testpassword123",
        "role": "analyst"
    }
    signup_response = client.post("/api/v1/auth/signup", json=signup_payload)
    assert signup_response.status_code == 200
    assert signup_response.json()["username"] == "testuser"
    assert signup_response.json()["role"] == "analyst"


    # 2. Login
    login_payload = {
        "username": "testuser",
        "password": "testpassword123"
    }
    login_response = client.post("/api/v1/auth/login", json=login_payload)
    assert login_response.status_code == 200
    assert "access_token" in login_response.json()
    token = login_response.json()["access_token"]
    
    # 3. Access /me protected route
    me_response = client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert me_response.status_code == 200
    assert me_response.json()["username"] == "testuser"

def test_lakes_and_predictions():
    # Setup auth token (using admin credentials to pass RBAC checks for creating a lake)
    login_payload = {"username": "adminuser", "password": "adminpassword123"}
    token = client.post("/api/v1/auth/login", json=login_payload).json()["access_token"]


    # 1. Create a Lake
    lake_payload = {
        "name": "Test Reservoir",
        "latitude": 40.7128,
        "longitude": -74.0060,
        "location_code": "TR_01",
        "active_status": "Active"
    }
    lake_response = client.post(
        "/api/v1/api/v1/lakes" if "/api/v1/api/v1" in app.routes else "/api/v1/lakes",
        json=lake_payload,
        headers={"Authorization": f"Bearer {token}"}
    )
    # Check fallback path depending on route prefix mounting
    assert lake_response.status_code in [200, 201]
    lake_id = lake_response.json()["id"]

    # 2. Run Prediction on the created lake
    pred_payload = {
        "lake_id": lake_id,
        "temperature": 26.5,
        "ph": 8.4,
        "rainfall": 1.2,
        "humidity": 60.0,
        "wind_speed": 10.5,
        "sunlight": 7.5,
        "dissolved_oxygen": 4.8,
        "conductivity": 220.0,
        "bod": 2.5,
        "nitrogen": 0.85,
        "phosphorus": 0.05,
        "season": "Summer"
    }
    pred_response = client.post(
        "/api/v1/predictions/",
        json=pred_payload,
        headers={"Authorization": f"Bearer {token}"}
    )
    assert pred_response.status_code == 200
    assert "bloom_severity" in pred_response.json()
    assert "health_risk" in pred_response.json()
