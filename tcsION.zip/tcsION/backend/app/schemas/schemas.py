from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# Authentication Schemas
class UserBase(BaseModel):
    username: str
    email: EmailStr

class UserCreate(UserBase):
    password: str
    role: Optional[str] = "guest"  # admin, researcher, analyst, guest

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(UserBase):
    id: int
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str

class TokenData(BaseModel):
    username: Optional[str] = None

# Lake Schemas
class LakeBase(BaseModel):
    name: str
    latitude: float
    longitude: float
    location_code: str
    active_status: Optional[str] = "Active"

class LakeCreate(LakeBase):
    pass

class LakeResponse(LakeBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Prediction Schemas
class PredictionInput(BaseModel):
    temperature: float = Field(..., description="Temperature in Celsius")
    ph: float = Field(..., description="pH level of the water")
    rainfall: float = Field(..., description="Precipitation in mm")
    humidity: float = Field(..., description="Humidity percentage")
    wind_speed: float = Field(..., description="Wind speed in km/h")
    sunlight: float = Field(..., description="Sunlight duration/UV index")
    dissolved_oxygen: float = Field(..., description="Dissolved Oxygen (mg/L)")
    conductivity: float = Field(..., description="Conductivity (uS/cm)")
    bod: float = Field(..., description="Biological Oxygen Demand (mg/L)")
    nitrogen: float = Field(..., description="Nitrogen (mg/L)")
    phosphorus: float = Field(..., description="Phosphorus (mg/L)")
    season: str = Field(..., description="Season (Spring, Summer, Autumn, Winter)")

class PredictionCreate(PredictionInput):
    lake_id: int

class PredictionResponse(BaseModel):
    id: int
    lake_id: int
    timestamp: datetime
    temperature: float
    ph: float
    rainfall: float
    humidity: float
    wind_speed: float
    sunlight: float
    dissolved_oxygen: float
    conductivity: float
    bod: float
    nitrogen: float
    phosphorus: float
    season: str
    bloom_severity: str
    health_risk: str
    confidence_score: float
    probabilities_json: Optional[Dict[str, float]]
    shap_explanation_json: Optional[Dict[str, Any]]
    recommendations: Optional[str]
    is_alert_triggered: bool

    class Config:
        from_attributes = True

# Prediction Simulation ("What-If")
class SimulationInput(BaseModel):
    base_prediction_id: int
    modifications: Dict[str, float]  # Fields to modify (e.g. {"temperature": 28.0, "phosphorus": 0.05})

class SimulationResponse(BaseModel):
    before: Dict[str, Any]  # e.g., {"bloom_severity": "High", "health_risk": "High", "confidence": 0.85}
    after: Dict[str, Any]   # e.g., {"bloom_severity": "Moderate", "health_risk": "Low", "confidence": 0.72}
    improvement_percentage: float

# Alert Schemas
class AlertResponse(BaseModel):
    id: int
    lake_id: int
    prediction_id: int
    severity: str
    message: str
    is_resolved: bool
    created_at: datetime

    class Config:
        from_attributes = True

# Dataset Schemas
class DatasetResponse(BaseModel):
    id: int
    name: str
    filename: str
    row_count: int
    col_count: int
    data_quality_score: float
    duplicate_count: int
    missing_count: int
    outlier_count: int
    stats_json: Optional[Dict[str, Any]]
    upload_timestamp: datetime

    class Config:
        from_attributes = True

# Model Registry Schemas
class ModelRegistryResponse(BaseModel):
    id: int
    name: str
    version: int
    model_type: str
    accuracy: float
    f1_score: float
    precision_score: float
    recall_score: float
    auc_score: float
    is_active: bool
    parameters_json: Optional[Dict[str, Any]]
    metrics_history_json: Optional[Dict[str, Any]]
    created_at: datetime

    class Config:
        from_attributes = True

# Chat Schemas
class ChatRequest(BaseModel):
    message: str
    history: Optional[List[Dict[str, str]]] = []
    prediction_context: Optional[Dict[str, Any]] = None

class ChatResponse(BaseModel):
    response: str
    sources: Optional[List[str]] = []

# Dashboard Stats Schemas
class DashboardStats(BaseModel):
    total_lakes: int
    total_predictions: int
    todays_predictions: int
    high_risk_lakes: int
    moderate_risk_lakes: int
    low_risk_lakes: int
    avg_accuracy: float
    latest_alerts: List[AlertResponse]
    model_status: str  # e.g., "Active Model: CatBoost v3"
