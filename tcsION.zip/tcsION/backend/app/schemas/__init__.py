# AquaSafe AI Schemas Package
